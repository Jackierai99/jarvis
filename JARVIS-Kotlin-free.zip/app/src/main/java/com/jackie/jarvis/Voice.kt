package com.jackie.jarvis

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.PlaybackParams
import android.os.Bundle
import android.util.Base64
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.atomic.AtomicInteger

/** JARVIS ki apni awaaz: OpenAI text-to-speech (phone ka system voice use nahi hota) */
object Voice {
    private const val STYLE = "Speak like a warm, relaxed young Indian friend chatting casually. Natural, expressive, a little playful, with human pauses and emotion. Never sound like a robot or a news announcer. Pronounce Hindi and Hinglish naturally."
    private val names = listOf("coral", "nova", "shimmer", "onyx", "echo", "ash")

    private lateinit var app: Context
    private var started = false
    private val texts = LinkedBlockingQueue<Pair<Int, String>>()
    private val audios = LinkedBlockingQueue<Pair<Int, ByteArray?>>(4)
    private val outstanding = AtomicInteger(0)
    @Volatile private var epoch = 0
    @Volatile private var track: AudioTrack? = null
    var onIdle: () -> Unit = {}
    var onError: (String) -> Unit = {}

    val busy: Boolean get() = outstanding.get() > 0

    fun init(c: Context) {
        if (started) return
        started = true
        app = c.applicationContext
        Thread { fetchLoop() }.apply { isDaemon = true }.start()
        Thread { playLoop() }.apply { isDaemon = true }.start()
    }

    // ---- FREE: phone ki apni (system) awaaz, koi API/paisa nahi ----
    private var sys: TextToSpeech? = null
    private var sysReady = false
    private val uid = AtomicInteger(0)

    /** Cloud TTS tabhi jab user ne alag TTS link diya ho ya OpenAI ki key ho; warna phone ki awaaz */
    private fun useCloud(): Boolean {
        if (Prefs.get(app, "tts_base").isNotBlank()) return true
        if (isGemini() && Ai.key(app).isNotEmpty()) return true
        return Ai.base(app).contains("api.openai.com") && Prefs.get(app, "tts_key").trim().ifBlank { Ai.key(app) }.isNotEmpty()
    }

    private fun isGemini() = Prefs.get(app, "tts_base").isBlank() && Ai.base(app).contains("generativelanguage.googleapis.com")

    /** Gemini TTS (free key se): natural awaaz, 24kHz PCM */
    private fun geminiSynth(text: String): ByteArray {
        val key = Prefs.get(app, "tts_key").trim().ifBlank { Ai.key(app) }
        val custom = Prefs.get(app, "tts_model").trim()
        val models = if (custom.isNotBlank()) listOf(custom) else listOf("gemini-3.8-flash-tts", "gemini-3.8-flash-lite-tts", "gemini-3.1-flash-tts-preview")
        val voice = Prefs.get(app, "tts_voice").trim().ifBlank { listOf("Kore", "Aoede", "Leda", "Puck", "Charon", "Fenrir")[(Prefs.get(app, "voice", "0").toIntOrNull() ?: 0).coerceIn(0, 5)] }
        var err = ""
        for (m in models) {
            try {
                val txt = JSONObject().put("type", "text").put("text", text)
                    .put("annotations", org.json.JSONArray().put(JSONObject().put("type", "speech_metadata").put("style", "warm, relaxed, friendly young Indian friend, natural Hindi/Hinglish, a little playful")))
                val b = JSONObject().put("model", m)
                    .put("input", org.json.JSONArray().put(JSONObject().put("type", "user_input").put("content", org.json.JSONArray().put(txt))))
                    .put("response_format", JSONObject().put("type", "audio").put("mime_type", "audio/l16").put("sample_rate", 24000))
                    .put("generation_config", JSONObject().put("speech_config", org.json.JSONArray().put(JSONObject().put("voice", voice))))
                val c = URL("https://generativelanguage.googleapis.com/v1beta/interactions").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.doOutput = true
                c.connectTimeout = 6000; c.readTimeout = 30000
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("x-goog-api-key", key)
                c.outputStream.use { it.write(b.toString().toByteArray()) }
                if (c.responseCode !in 200..299) {
                    val t = c.errorStream?.bufferedReader()?.readText() ?: ""
                    throw Exception("HTTP ${c.responseCode} ${t.take(200)}")
                }
                val steps = JSONObject(c.inputStream.bufferedReader().readText()).optJSONArray("steps") ?: throw Exception("no audio")
                val out = java.io.ByteArrayOutputStream()
                for (i in 0 until steps.length()) {
                    val cs = steps.getJSONObject(i).optJSONArray("content") ?: continue
                    for (j in 0 until cs.length()) {
                        val o = cs.getJSONObject(j)
                        if (o.optString("type") == "audio") out.write(Base64.decode(o.optString("data"), Base64.DEFAULT))
                    }
                }
                if (out.size() == 0) throw Exception("empty audio")
                return out.toByteArray()
            } catch (e: Exception) { err = e.message ?: "error"; if (err.contains("401") || err.contains("403")) break }
        }
        throw Exception(err)
    }

    private fun sysInit(after: () -> Unit) {
        if (sys != null) { after(); return }
        sys = TextToSpeech(app) { st ->
            if (st == TextToSpeech.SUCCESS) {
                val l = Locale.forLanguageTag(Prefs.get(app, "lang", "hi-IN"))
                val r = sys?.setLanguage(l) ?: TextToSpeech.LANG_NOT_SUPPORTED
                if (r < 0) sys?.setLanguage(Locale("hi", "IN"))
                sys?.setSpeechRate(Prefs.get(app, "rate", "1.0").toFloatOrNull() ?: 1f)
                sys?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { if (id?.substringBefore(':')?.toIntOrNull() == epoch) done() }
                    @Deprecated("x") override fun onError(id: String?) { if (id?.substringBefore(':')?.toIntOrNull() == epoch) done() }
                })
                sysReady = true
                after()
            } else { sys = null; onError("Phone ki TTS awaaz nahi mili (Settings > Text-to-speech engine check karo)"); done() }
        }
    }

    private fun sysSay(t: String) {
        val id = "$epoch:${uid.incrementAndGet()}"
        sysInit { sys?.speak(t, TextToSpeech.QUEUE_ADD, Bundle(), id) }
    }

    fun say(t: String) {
        if (Prefs.get(app, "voice_on", "1") == "0" || t.isBlank()) return
        if (!useCloud()) { outstanding.incrementAndGet(); sysSay(t); return }
        outstanding.incrementAndGet()
        texts.put(epoch to t)
    }

    fun stop() {
        epoch++
        texts.clear(); audios.clear()
        try { track?.pause(); track?.flush() } catch (_: Exception) {}
        try { sys?.stop() } catch (_: Exception) {}
        outstanding.set(0)
    }

    private fun done() {
        if (outstanding.decrementAndGet() <= 0) { outstanding.set(0); onIdle() }
    }

    private fun fetchLoop() {
        while (true) {
            val (e, t) = texts.take()
            if (e != epoch) continue
            val pcm = try { if (isGemini()) geminiSynth(t) else synth(t) } catch (ex: Exception) {
                if (isGemini()) { onError("Gemini awaaz fail, phone ki awaaz: " + (ex.message ?: "").take(80)); sysSay(t); continue }
                onError(Ai.friendly(ex.message)); null
            }
            if (e != epoch) continue
            audios.put(e to pcm)
        }
    }

    private fun playLoop() {
        while (true) {
            val (e, pcm) = audios.take()
            if (e != epoch) continue
            if (pcm != null) try { play(pcm, e) } catch (ex: Exception) { onError("Audio play error: ${ex.message}") }
            if (e == epoch) done()
        }
    }

    private fun voiceName(): String {
        val o = Prefs.get(app, "tts_voice").trim()
        if (o.isNotBlank()) return o
        return names[(Prefs.get(app, "voice", "0").toIntOrNull() ?: 0).coerceIn(0, 5)]
    }

    private fun synth(text: String): ByteArray {
        val key = Prefs.get(app, "tts_key").trim().ifBlank { Ai.key(app) }
        if (key.isEmpty()) throw Exception("Settings me API key daalo (awaaz ke liye bhi wahi key chalti hai)")
        val base = Prefs.get(app, "tts_base").trim().ifBlank { Ai.base(app) }.trimEnd('/')
        val model = Prefs.get(app, "tts_model").trim().ifBlank { "gpt-4o-mini-tts" }
        fun post(withStyle: Boolean): ByteArray {
            val b = JSONObject().put("model", model).put("input", text).put("voice", voiceName()).put("response_format", "pcm")
            if (withStyle) b.put("instructions", STYLE)
            val c = URL("$base/audio/speech").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true
            c.connectTimeout = 6000; c.readTimeout = 25000
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Authorization", "Bearer $key")
            c.outputStream.use { it.write(b.toString().toByteArray()) }
            if (c.responseCode !in 200..299) {
                val t = c.errorStream?.bufferedReader()?.readText() ?: ""
                throw Exception("HTTP ${c.responseCode} ${t.take(200)}")
            }
            return c.inputStream.use { it.readBytes() }
        }
        try { return post(true) } catch (e: Exception) {
            if ((e.message ?: "").contains("400")) return post(false)
            throw e
        }
    }

    private fun play(pcm: ByteArray, e: Int) {
        val min = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val tr = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(min, 24000))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track = tr
        try {
            val rate = Prefs.get(app, "rate", "1.0").toFloatOrNull() ?: 1f
            if (rate != 1f) tr.playbackParams = PlaybackParams().setSpeed(rate).setPitch(1f)
        } catch (_: Exception) {}
        tr.play()
        var off = 0
        while (off < pcm.size && e == epoch) {
            val n = tr.write(pcm, off, minOf(4096, pcm.size - off))
            if (n <= 0) break
            off += n
        }
        val frames = pcm.size / 2
        var guard = 0
        while (e == epoch && tr.playbackHeadPosition < frames && guard < 600) { Thread.sleep(25); guard++ }
        try { tr.stop() } catch (_: Exception) {}
        tr.release()
    }

    /** Settings ka awaaz test: asli error dikhata hai */
    fun test(): String = if (!useCloud()) {
        say("नमस्ते भाई, मैं जार्विस हूँ। ये फोन की फ्री आवाज़ है।"); "✅ Phone ki free awaaz (agar sunayi nahi di to Settings > Text-to-speech me Hindi voice install karo)"
    } else try {
        val pcm = (if (isGemini()) ::geminiSynth else ::synth)("नमस्ते भाई, मैं जार्विस हूँ। ये मेरी अपनी आवाज़ है।")
        play(pcm, epoch)
        "✅ Awaaz chal gayi"
    } catch (e: Exception) {
        "❌ " + Ai.friendly(e.message)
    }
}
