package com.jackie.jarvis

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class JarvisAccess : AccessibilityService() {
    companion object { var inst: JarvisAccess? = null }

    @Volatile var lastRects: List<Rect> = emptyList()

    override fun onServiceConnected() { inst = this }
    override fun onDestroy() { inst = null; super.onDestroy() }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun global(x: String): String {
        val g = when (x) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "quick" -> GLOBAL_ACTION_QUICK_SETTINGS
            "screenshot" -> GLOBAL_ACTION_TAKE_SCREENSHOT
            "lock" -> GLOBAL_ACTION_LOCK_SCREEN
            "power" -> GLOBAL_ACTION_POWER_DIALOG
            else -> return "bad global $x"
        }
        performGlobalAction(g)
        return ""
    }

    /** Screen ki numbered list: #index [btn]/[input] text (x,y) */
    fun screen(): String {
        val sb = StringBuilder()
        val rects = ArrayList<Rect>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || rects.size >= 70 || sb.length > 3200) return
            if (!n.isVisibleToUser) return
            val t = (n.text ?: n.contentDescription)?.toString()?.replace("\n", " ")?.take(60)
            if (n.isClickable || n.isEditable || !t.isNullOrBlank()) {
                val r = Rect()
                n.getBoundsInScreen(r)
                if (r.width() > 0 && r.height() > 0) {
                    rects.add(r)
                    sb.append('#').append(rects.size - 1).append(' ')
                        .append(if (n.isEditable) "[input] " else if (n.isClickable) "[btn] " else "")
                        .append(t ?: "").append(" (").append(r.centerX()).append(',').append(r.centerY()).append(")\n")
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        val root = rootInActiveWindow
        walk(root)
        lastRects = rects
        return "SCREEN(app=${root?.packageName}):\n$sb"
    }

    private fun gesture(p: Path, dur: Long) {
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build(), null, null)
    }

    fun tapXY(x: Float, y: Float, dur: Long = 60): String {
        val p = Path(); p.moveTo(x, y); gesture(p, dur); return ""
    }

    private fun nums(a: String, n: Int): List<Float>? {
        val l = a.split(",").mapNotNull { it.trim().toFloatOrNull() }
        return if (l.size >= n) l else null
    }

    fun tap(a: String): String { val l = nums(a, 2) ?: return "x,y galat"; return tapXY(l[0], l[1]) }
    fun longPress(a: String): String { val l = nums(a, 2) ?: return "x,y galat"; return tapXY(l[0], l[1], 800) }

    fun swipe(a: String): String {
        val l = nums(a, 4) ?: return "x1,y1,x2,y2 galat"
        val p = Path(); p.moveTo(l[0], l[1]); p.lineTo(l[2], l[3]); gesture(p, 350)
        return ""
    }

    fun tapNode(a: String): String {
        val i = a.trim().removePrefix("#").toIntOrNull() ?: return "number galat"
        val r = lastRects.getOrNull(i) ?: return "node nahi mila, pehle read_screen karo"
        return tapXY(r.centerX().toFloat(), r.centerY().toFloat())
    }

    fun click(t: String): String {
        val r = rootInActiveWindow ?: return "window nahi mili"
        for (n in r.findAccessibilityNodeInfosByText(t)) {
            var p: AccessibilityNodeInfo? = n
            while (p != null && !p.isClickable) p = p.parent
            if (p != null) { p.performAction(AccessibilityNodeInfo.ACTION_CLICK); return "" }
            val b = Rect(); n.getBoundsInScreen(b)
            if (b.width() > 0) return tapXY(b.centerX().toFloat(), b.centerY().toFloat())
        }
        return "'$t' screen pe nahi mila"
    }

    private fun clickId(id: String): Boolean {
        val r = rootInActiveWindow ?: return false
        for (n in r.findAccessibilityNodeInfosByViewId(id)) {
            var p: AccessibilityNodeInfo? = n
            while (p != null && !p.isClickable) p = p.parent
            if (p != null) { p.performAction(AccessibilityNodeInfo.ACTION_CLICK); return true }
        }
        return false
    }

    /** ms tak baar baar try karta hai (screen load hone ka wait) */
    fun waitClick(ids: List<String>, texts: List<String>, ms: Long): String {
        val end = System.currentTimeMillis() + ms
        while (System.currentTimeMillis() < end) {
            for (id in ids) if (clickId(id)) return ""
            for (t in texts) if (click(t).isEmpty()) return ""
            try { Thread.sleep(400) } catch (_: Exception) {}
        }
        return "button nahi mila"
    }

    fun clickAny(l: List<String>): String {
        for (t in l) if (click(t).isEmpty()) return ""
        return "button nahi mila"
    }

    private fun findEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable) return n
        for (i in 0 until n.childCount) findEditable(n.getChild(i))?.let { return it }
        return null
    }

    fun enter(): String {
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return "koi text box nahi"
        if (Build.VERSION.SDK_INT >= 30) f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        return ""
    }

    fun type(t: String): String {
        val root = rootInActiveWindow ?: return "window nahi mili"
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root) ?: return "koi text box nahi mila"
        f.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
        return ""
    }

    fun scroll(dir: String): String {
        val m = resources.displayMetrics
        val w = m.widthPixels / 2f
        val h = m.heightPixels.toFloat()
        val p = Path()
        if (dir == "down") { p.moveTo(w, h * 0.7f); p.lineTo(w, h * 0.3f) } else { p.moveTo(w, h * 0.3f); p.lineTo(w, h * 0.7f) }
        gesture(p, 300)
        return ""
    }
}
