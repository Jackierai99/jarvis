package com.jackie.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val req = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) go()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Engine.init(this)
        if (Prefs.get(this, "autostart", "1") == "1" && !Engine.listening.value) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) go() else askPerms()
        }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cy, background = Color(0xFF000814), surface = Color(0xFF001A33))) {
                var s by remember { mutableStateOf(false) }
                if (s) SettingsScreen { s = false } else Hud({ toggle() }, { s = true })
            }
        }
    }

    override fun onStart() { super.onStart(); Overlay.hide() }

    override fun onStop() {
        super.onStop()
        if (Engine.listening.value) Overlay.show(this)
    }

    private fun askPerms() {
        req.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS, Manifest.permission.SEND_SMS, Manifest.permission.POST_NOTIFICATIONS))
    }

    private fun toggle() {
        if (Engine.listening.value) stopService(Intent(this, JarvisService::class.java))
        else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) go()
        else req.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS, Manifest.permission.SEND_SMS, Manifest.permission.POST_NOTIFICATIONS))
    }

    private fun go() { ContextCompat.startForegroundService(this, Intent(this, JarvisService::class.java)) }
}
