package com.jackie.jarvis

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    fun get(c: Context, k: String, d: String = ""): String = sp(c).getString(k, d) ?: d
    fun set(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
}

/** Groq (OpenAI-style API). Ek hi API: key Settings me daalo. */
object Ai {
    fun base(c: Context): String = "https://api.groq.com/openai/v1"
    fun key(c: Context): String = Prefs.get(c, "key_ai").trim()

    private val models = listOf("openai/gpt-oss-20b", "llama-3.1-8b-instant", "openai/gpt-oss-120b")

    fun friendly(m: String?): String {
        val e = m ?: "error"
        return when {
            e.contains("401") || e.contains("invalid_api_key", true) -> "API key galat hai (console.groq.com/keys se nayi lo)"
            e.contains("429") || e.contains("rate", true) -> "Groq ki limit lag gayi, thodi der baad try karo"
            e.contains("404") || e.contains("model", true) && e.contains("exist", true) -> "Ye model nahi mila (Settings me model naam badlo)"
            e.contains("timeout", true) || e.contains("Unable to resolve") || e.contains("failed to connect", true) -> "Internet ya network problem (timeout)"
            else -> e.take(150)
        }
    }

    private fun getJson(url: String, key: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 6000; c.readTimeout = 15000
        c.setRequestProperty("Authorization", "Bearer $key")
        val ok = c.responseCode in 200..299
        val t = (if (ok) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        if (!ok) throw Exception("HTTP ${c.responseCode} ${t.take(200)}")
        return t
    }

    private fun body(model: String, system: String, hist: List<Pair<String, String>>, full: Boolean): JSONObject {
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system))
        hist.forEach { (r, t) -> msgs.put(JSONObject().put("role", r).put("content", t)) }
        val b = JSONObject().put("model", model).put("messages", msgs).put("stream", true)
        if (full) {
            b.put("response_format", JSONObject().put("type", "json_object"))
            b.put("max_completion_tokens", 1500)
            if (model.contains("gpt-oss")) b.put("reasoning_effort", "low")
        }
        return b
    }

    private fun stream(ctx: Context, model: String, system: String, hist: List<Pair<String, String>>, full: Boolean, onText: (String) -> Unit): String {
        val c = URL(base(ctx) + "/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true
        c.connectTimeout = 6000; c.readTimeout = 20000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Authorization", "Bearer " + key(ctx))
        c.outputStream.use { it.write(body(model, system, hist, full).toString().toByteArray()) }
        if (c.responseCode !in 200..299) {
            val t = c.errorStream?.bufferedReader()?.readText() ?: ""
            throw Exception("HTTP ${c.responseCode} ${t.take(220)}")
        }
        val sb = StringBuilder()
        c.inputStream.bufferedReader().use { r ->
            while (true) {
                val line = r.readLine() ?: break
                if (!line.startsWith("data:")) continue
                val js = line.substring(5).trim()
                if (js.isEmpty()) continue
                if (js == "[DONE]") break
                try {
                    val d = JSONObject(js).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("delta")
                    val t = d?.optString("content", "") ?: ""
                    if (t.isNotEmpty()) { sb.append(t); onText(sb.toString()) }
                } catch (_: Exception) {}
            }
        }
        if (sb.isBlank()) throw Exception("empty reply")
        return sb.toString()
    }

    private fun ask(ctx: Context, model: String, system: String, hist: List<Pair<String, String>>, onText: (String) -> Unit): String {
        try { return stream(ctx, model, system, hist, true, onText) } catch (e: Exception) {
            if ((e.message ?: "").contains("400")) return stream(ctx, model, system, hist, false, onText)
            throw e
        }
    }

    private fun order(ctx: Context): List<String> {
        val custom = Prefs.get(ctx, "model_ai").trim()
        if (custom.isNotBlank()) return listOf(custom)
        return listOfNotNull(Prefs.get(ctx, "model_ok").ifBlank { null }).plus(models).distinct()
    }

    fun chat(ctx: Context, system: String, hist: List<Pair<String, String>>, onText: (String) -> Unit): String {
        if (key(ctx).isEmpty()) throw Exception("Settings me Groq API key daalo")
        val t0 = System.currentTimeMillis()
        var err = ""
        for (m in order(ctx)) {
            if (System.currentTimeMillis() - t0 > 30000) break
            try {
                val r = ask(ctx, m, system, hist, onText)
                Prefs.set(ctx, "model_ok", m)
                return r
            } catch (e: Exception) {
                err = e.message ?: "error"
                if (err.contains("401")) break
            }
        }
        throw Exception(friendly(err))
    }

    /** Settings ka "Key test" button */
    fun test(ctx: Context): String {
        if (key(ctx).isEmpty()) return "❌ Pehle API key daalo"
        val sb = StringBuilder()
        val names = ArrayList<String>()
        try {
            val arr = JSONObject(getJson(base(ctx) + "/models", key(ctx))).optJSONArray("data") ?: JSONArray()
            for (i in 0 until arr.length()) names.add(arr.getJSONObject(i).optString("id"))
            sb.append("✅ Key sahi hai (${names.size} models mile)\n")
        } catch (e: Exception) {
            return "❌ Key check fail: ${friendly(e.message)}"
        }
        val custom = Prefs.get(ctx, "model_ai").trim()
        val chosen = if (custom.isNotBlank()) custom
        else models.firstOrNull { it in names }
            ?: return sb.append("❌ Koi chat model nahi mila (Settings me model naam daalo)").toString()
        if (custom.isBlank()) Prefs.set(ctx, "model_ok", chosen)
        return try {
            val t0 = System.currentTimeMillis()
            ask(ctx, chosen, "Reply only JSON.", listOf("user" to "Return {\"say\":\"OK\"}")) {}
            val s = (System.currentTimeMillis() - t0) / 1000.0
            sb.append("✅ Reply mila (${"%.1f".format(s)}s)\nModel: $chosen").toString()
        } catch (e: Exception) {
            sb.append("❌ Reply fail ($chosen): ${friendly(e.message)}").toString()
        }
    }
}
