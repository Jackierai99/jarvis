package com.jackie.jarvis

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch
import kotlin.math.abs

class OrbView(c: Context) : View(c) {
    var level = 0f
    var st = "IDLE"
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmp: Bitmap = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(c.resources, R.drawable.logo), 180, 180, true)
    private val clip = Path()

    override fun onDraw(cv: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = width / 2f
        val col = when (st) {
            "THINK", "PROCESS" -> 0xFFFFC107.toInt()
            "EXECUTE" -> 0xFF69F0AE.toInt()
            "ASSIST" -> 0xFF40C4FF.toInt()
            else -> 0xFF00E5FF.toInt()
        }
        p.style = Paint.Style.FILL; p.color = col; p.alpha = 50
        cv.drawCircle(cx, cy, r * (0.78f + level * 0.2f), p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.color = col; p.alpha = 255
        cv.drawCircle(cx, cy, r * (0.74f + level * 0.2f), p)
        clip.reset(); clip.addCircle(cx, cy, r * 0.62f, Path.Direction.CW)
        cv.save(); cv.clipPath(clip)
        cv.drawBitmap(bmp, null, RectF(cx - r * .62f, cy - r * .62f, cx + r * .62f, cy + r * .62f), null)
        cv.restore()
    }
}

/** App background me jaye to ChatGPT voice jaisa floating gol + live text */
object Overlay {
    private var wm: WindowManager? = null
    private var root: LinearLayout? = null
    private var job: Job? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())
    private var tv: TextView? = null
    private var u = ""
    private var b = ""
    private val hideText = Runnable { tv?.visibility = View.GONE }

    private fun render() {
        val t = listOf(u, b).filter { it.isNotBlank() }.joinToString("\n")
        tv?.let {
            it.text = t
            it.visibility = if (t.isBlank()) View.GONE else View.VISIBLE
        }
        handler.removeCallbacks(hideText)
        handler.postDelayed(hideText, 9000)
    }

    fun show(c: Context) {
        val ctx = c.applicationContext
        if (root != null || !Settings.canDrawOverlays(ctx) || Prefs.get(ctx, "overlay", "1") != "1") return
        val w = ctx.getSystemService(WindowManager::class.java)
        wm = w
        val dp = ctx.resources.displayMetrics.density
        val orb = OrbView(ctx)
        val text = TextView(ctx).apply {
            setTextColor(0xFFFFFFFF.toInt()); textSize = 14f
            setPadding((12 * dp).toInt(), (8 * dp).toInt(), (12 * dp).toInt(), (8 * dp).toInt())
            background = GradientDrawable().apply {
                setColor(0xE6001A33.toInt()); cornerRadius = 16 * dp; setStroke((1 * dp).toInt(), 0x8800E5FF.toInt())
            }
            maxWidth = (250 * dp).toInt()
            visibility = View.GONE
        }
        tv = text
        val lay = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
            addView(text, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = (6 * dp).toInt() })
            addView(orb, LinearLayout.LayoutParams((72 * dp).toInt(), (72 * dp).toInt()))
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = ctx.resources.displayMetrics.widthPixels - (110 * dp).toInt()
            y = (220 * dp).toInt()
        }
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        orb.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = params.x; sy = params.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx
                    val dy = e.rawY - ty
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    params.x = sx + dx.toInt(); params.y = sy + dy.toInt()
                    w.updateViewLayout(lay, params)
                }
                MotionEvent.ACTION_UP -> if (!moved) ctx.startActivity(Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
            }
            true
        }
        try { w.addView(lay, params) } catch (e: Exception) { return }
        root = lay
        u = ""; b = ""
        job = scope.launch {
            launch { Engine.level.collect { orb.level = it; orb.invalidate() } }
            launch { Engine.state.collect { orb.st = it; orb.invalidate() } }
            launch { Engine.heard.drop(1).collect { if (it.isNotBlank()) { u = "🗣 $it"; b = ""; render() } } }
            launch { Engine.reply.drop(1).collect { if (it.isNotBlank()) { b = "🤖 $it"; render() } } }
        }
    }

    fun hide() {
        job?.cancel(); job = null
        handler.removeCallbacks(hideText)
        root?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        root = null; tv = null
    }
}
