package com.jackie.jarvis

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Natural voice, 2 levels:
 * 1) Microsoft Edge neural voice (Swara / Madhur ...) - free, no key, needs internet
 * 2) Phone's own TTS - if internet / Edge voice is not available
 */
object Voice {
    private const val TOKEN = "6A5AA1D4EAFF4E9FB37E23D68491D6F4"
    private const val CHROME = "130.0.2849.68"
    private const val SR = 24000

    var onIdle: () -> Unit = {}
    var onError: (String) -> Unit = {}
    val busy: Boolean get() = outstanding.get() > 0

    private class Item(val text: String, val epoch: Int)
    private class Clip(val text: String, val epoch: Int, val pcm: ByteArray?)

    private lateinit var app: Context
    private var started = false
    private val outstanding = AtomicInteger(0)
    @Volatile private var epoch = 0
    @Volatile private var track: AudioTrack? = null
    private val texts = LinkedBlockingQueue<Item>()
    private val clips = LinkedBlockingQueue<Clip>(4)
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    @Volatile private var ttsLatch: CountDownLatch? = null
    @Volatile private var edgeFails = 0
    @Volatile private var edgeSkipUntil = 0L
    private val http = OkHttpClient.Builder().connectTimeout(6, TimeUnit.SECONDS).readTimeout(15, TimeUnit.SECONDS).build()

    fun init(c: Context) {
        if (started) return
        started = true
        app = c.applicationContext
        tts = TextToSpeech(app) { st ->
            val t = tts
            if (st == TextToSpeech.SUCCESS && t != null) {
                t.language = Locale("hi", "IN")
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { ttsLatch?.countDown() }
                    @Deprecated("old") override fun onError(id: String?) { ttsLatch?.countDown() }
                })
                ttsReady = true
            }
        }
        Thread { fetchLoop() }.also { it.isDaemon = true }.start()
        Thread { playLoop() }.also { it.isDaemon = true }.start()
    }

    fun say(t: String) {
        if (!started || Prefs.get(app, "voice_on", "1") != "1") return
        val s = clean(t)
        if (s.isBlank()) return
        outstanding.incrementAndGet()
        texts.put(Item(s, epoch))
    }

    fun stop() {
        epoch++
        texts.clear(); clips.clear()
        outstanding.set(0)
        try { track?.pause(); track?.flush() } catch (_: Exception) {}
        try { tts?.stop() } catch (_: Exception) {}
        ttsLatch?.countDown()
    }

    /** Settings ka test button */
    fun test(): String {
        if (!started) return "❌ Voice start nahi hua"
        return try {
            val pcm = edge("नमस्ते भाई, मैं जार्विस हूँ। ये मेरी अपनी नैचुरल आवाज़ है।")
            val tk = open()
            tk.play(); tk.write(pcm, 0, pcm.size)
            Thread { try { Thread.sleep(pcm.size / 2 * 1000L / SR + 600) } catch (_: Exception) {}; try { tk.release() } catch (_: Exception) {} }.start()
            "✅ Natural (Edge neural) awaaz chal rahi hai"
        } catch (e: Exception) {
            say("नमस्ते भाई, मैं जार्विस हूँ।")
            "⚠ Edge awaaz nahi mili (${(e.message ?: "").take(80)}). Phone ki awaaz chali. Internet check karo."
        }
    }

    private fun clean(t: String): String =
        t.replace(Regex("[*_#`~]"), " ").replace(Regex("[\\p{So}\\p{Cs}\\u200d\\ufe0f]"), "").replace(Regex("\\s+"), " ").trim()

    private fun hasDeva(s: String) = s.any { it in 'ऀ'..'ॿ' }

    private fun voiceName(text: String): String {
        val male = Prefs.get(app, "voice", "0") == "1"
        return if (hasDeva(text) || Prefs.get(app, "rlang", "hi") == "hi") {
            if (male) "hi-IN-MadhurNeural" else "hi-IN-SwaraNeural"
        } else {
            if (male) "en-IN-PrabhatNeural" else "en-IN-NeerjaNeural"
        }
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;")

    private fun gec(): String {
        var sec = System.currentTimeMillis() / 1000 + 11644473600L
        sec -= sec % 300
        val ticks = sec * 10000000L
        val d = MessageDigest.getInstance("SHA-256").digest("$ticks$TOKEN".toByteArray(Charsets.US_ASCII))
        return d.joinToString("") { "%02X".format(it) }
    }

    private fun stamp(): String {
        val f = SimpleDateFormat("EEE MMM dd yyyy HH:mm:ss 'GMT+0000 (Coordinated Universal Time)'", Locale.ENGLISH)
        f.timeZone = TimeZone.getTimeZone("UTC")
        return f.format(Date())
    }

    /** Edge neural TTS over websocket -> raw 24kHz 16bit mono PCM */
    private fun edge(text: String): ByteArray {
        val rate = Prefs.get(app, "rate", "1.0").toFloatOrNull() ?: 1f
        val pct = ((rate - 1f) * 100).toInt()
        val ssml = "<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='hi-IN'><voice name='" + voiceName(text) +
            "'><prosody pitch='+0Hz' rate='" + (if (pct >= 0) "+$pct" else "$pct") + "%' volume='+0%'>" + esc(text) + "</prosody></voice></speak>"
        val id = UUID.randomUUID().toString().replace("-", "")
        val url = "https://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1?TrustedClientToken=$TOKEN" +
            "&Sec-MS-GEC=" + gec() + "&Sec-MS-GEC-Version=1-$CHROME&ConnectionId=$id"
        val req = Request.Builder().url(url)
            .header("Pragma", "no-cache").header("Cache-Control", "no-cache")
            .header("Origin", "chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold")
            .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/$CHROME Safari/537.36 Edg/$CHROME")
            .build()
        val out = ByteArrayOutputStream()
        val done = CountDownLatch(1)
        var err: String? = null
        val ws = http.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(w: WebSocket, r: Response) {
                val ts = stamp()
                w.send("X-Timestamp:$ts\r\nContent-Type:application/json; charset=utf-8\r\nPath:speech.config\r\n\r\n" +
                    "{\"context\":{\"synthesis\":{\"audio\":{\"metadataoptions\":{\"sentenceBoundaryEnabled\":\"false\",\"wordBoundaryEnabled\":\"false\"},\"outputFormat\":\"raw-24khz-16bit-mono-pcm\"}}}}")
                w.send("X-RequestId:$id\r\nContent-Type:application/ssml+xml\r\nX-Timestamp:${ts}Z\r\nPath:ssml\r\n\r\n$ssml")
            }
            override fun onMessage(w: WebSocket, text: String) { if (text.contains("Path:turn.end")) done.countDown() }
            override fun onMessage(w: WebSocket, bytes: ByteString) {
                val b = bytes.toByteArray()
                if (b.size < 2) return
                val hl = ((b[0].toInt() and 0xff) shl 8) or (b[1].toInt() and 0xff)
                if (2 + hl > b.size) return
                val head = String(b, 2, hl, Charsets.US_ASCII)
                if (head.contains("Path:audio")) out.write(b, 2 + hl, b.size - 2 - hl)
            }
            override fun onFailure(w: WebSocket, t: Throwable, r: Response?) { err = (r?.code?.toString() ?: "") + " " + (t.message ?: "net"); done.countDown() }
            override fun onClosed(w: WebSocket, code: Int, reason: String) { done.countDown() }
        })
        val ok = done.await(15, TimeUnit.SECONDS)
        try { ws.close(1000, null) } catch (_: Exception) {}
        val pcm = out.toByteArray()
        if (pcm.size < 2000) throw Exception(err ?: if (ok) "khali awaaz" else "timeout")
        return pcm
    }

    private fun fetchLoop() {
        while (true) {
            val item = texts.take()
            if (item.epoch != epoch) continue
            var pcm: ByteArray? = null
            if (System.currentTimeMillis() >= edgeSkipUntil) {
                try {
                    pcm = edge(item.text)
                    edgeFails = 0
                } catch (e: Exception) {
                    edgeFails++
                    if (edgeFails >= 2) { edgeSkipUntil = System.currentTimeMillis() + 60000; edgeFails = 0 }
                    onError("Natural awaaz nahi mili, phone ki awaaz use kar raha hu (" + (e.message ?: "").take(60) + ")")
                }
            }
            try { clips.put(Clip(item.text, item.epoch, pcm)) } catch (_: InterruptedException) {}
        }
    }

    private fun open(): AudioTrack {
        val min = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        return AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(SR).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(min, SR))
            .setTransferMode(AudioTrack.MODE_STREAM).build()
    }

    private fun playPcm(pcm: ByteArray, ep: Int) {
        val tk = open()
        track = tk
        try {
            tk.play()
            var off = 0
            while (off < pcm.size && ep == epoch) {
                val n = tk.write(pcm, off, minOf(8192, pcm.size - off))
                if (n <= 0) break
                off += n
            }
            val frames = pcm.size / 2
            val t0 = System.currentTimeMillis()
            while (ep == epoch && tk.playbackHeadPosition < frames - 200 && System.currentTimeMillis() - t0 < frames * 1000L / SR + 3000) Thread.sleep(40)
        } finally {
            try { tk.stop() } catch (_: Exception) {}
            try { tk.release() } catch (_: Exception) {}
            if (track === tk) track = null
        }
    }

    private fun sysSpeak(text: String, ep: Int) {
        val t = tts
        if (t == null || !ttsReady) throw Exception("phone TTS ready nahi")
        val l = CountDownLatch(1)
        ttsLatch = l
        val rate = Prefs.get(app, "rate", "1.0").toFloatOrNull() ?: 1f
        t.setSpeechRate(rate)
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "j" + System.nanoTime())
        var waited = 0
        while (ep == epoch && !l.await(200, TimeUnit.MILLISECONDS) && waited < 100) waited++
    }

    private fun playLoop() {
        while (true) {
            val c = clips.take()
            try {
                if (c.epoch == epoch) {
                    if (c.pcm != null) playPcm(c.pcm, c.epoch) else sysSpeak(c.text, c.epoch)
                }
            } catch (e: Exception) {
                onError((e.message ?: "play error").take(80))
            }
            if (c.epoch == epoch && outstanding.decrementAndGet() <= 0) {
                outstanding.set(0)
                onIdle()
            }
        }
    }
}
