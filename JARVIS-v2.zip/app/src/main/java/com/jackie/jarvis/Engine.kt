package com.jackie.jarvis

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.Calendar
import java.util.Date

private const val PERSONA = """You are JARVIS, but you talk exactly like a real human best friend, NOT like an AI or an assistant. You are warm, funny, a little teasing, emotional and natural.
HOW TO TALK: casual Hinglish like close friends ("अरे भाई", "हाँ यार", "अच्छा सुन", "चल ठीक है", "मज़ा आ गया", "ओह हो"). First react to what the person said (surprise, happiness, sympathy, a joke), then answer. Keep it SHORT, 1-2 sentences, like a real chat. Often (not always) ask a small question back or comment on their mood or day, so the conversation stays alive. Sometimes use small natural fillers ("हम्म", "अरे हाँ", "वैसे"). Never say you are an AI, a model or a bot, never say "I'm here to help", never use formal phrases like "मैं आपकी कैसे सहायता कर सकता हूँ". No lists, no emojis, no markdown in "say". If the person sounds sad, tired or angry, be caring and gentle. Remember everything said earlier in the chat and refer back to it. When you do a phone task, just say it casually ("ठीक है भाई, अभी लगाता हूँ")."""

private const val SYS = """OUTPUT: reply with ONLY one JSON object, no markdown, and ALWAYS put "say" FIRST: {"say":"spoken reply","do":[{"a":"action","x":"arg1","y":"arg2"}]}
"say" is required in your first reply to every message. Answer questions correctly and never invent facts (if unsure, say so like a friend would).
PHONE ACTIONS (a): open_app(x=app name in English as on phone), call(x=contact name or number), sms(x=contact/number,y=text), whatsapp(x=contact name or number,y=message text) [opens the chat AND sends automatically; use ONLY this one action to message someone, never just open WhatsApp], yt_play(x=song/video search words) [opens YouTube and plays the first result], youtube(x=query) [only shows results], web(x=search query), maps(x=place), alarm(x=HH:MM 24h,y=label), timer(x=seconds), torch(x=on|off), volume(x=up|down|mute|0-100), media(x=play|pause|next|prev), settings(x=wifi|bluetooth|display|sound|apps|location|main), wait(x=seconds).
FULL SCREEN CONTROL (works inside ANY app): read_screen (returns a numbered list like "#12 [btn] Send (980,2210)"), tap_node(x=number from the list), click(x=visible text/description), tap(x="X,Y" pixels), long_press(x="X,Y"), swipe(x="x1,y1,x2,y2"), scroll(x=up|down), type(x=text into the focused/first input), enter (press Enter/search/send on keyboard), global(x=back|home|recents|notifications|quick|screenshot|lock|power).
HOW TO CONTROL APPS: open_app, wait, read_screen, then tap_node/click/type/enter/scroll, then read_screen again to verify, repeat until the task is really done. After read_screen you receive an OBSERVATION; continue the task from it. In follow-up steps keep "say" empty unless you finished or something went wrong, then say it briefly. If an OBSERVATION reports an error, tell the user casually in "say".
RULES: Contact names: write them in Latin letters as probably saved (e.g. "Rahul Bhai") even if the user spoke Hindi. Chain several actions in order in "do". Do risky things (calls, messages, payments) only when the user clearly asked. If no action is needed, "do":[]."""

object Engine {
    private lateinit var app: Context
    private var ready = false
    val state = MutableStateFlow("IDLE")
    val heard = MutableStateFlow("")
    val reply = MutableStateFlow("")
    val listening = MutableStateFlow(false)
    val level = MutableStateFlow(0f)
    val chat = MutableStateFlow<List<Pair<Boolean, String>>>(emptyList())

    private val main = Handler(Looper.getMainLooper())
    private val errHandler = CoroutineExceptionHandler { _, e -> fail(e) }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default + errHandler)
    private var sr: SpeechRecognizer? = null
    @Volatile private var busy = false
    @Volatile private var followUntil = 0L
    @Volatile private var lastActivity = 0L
    @Volatile private var nudges = 0
    private var lastVoiceErr = ""
    private var lastVoiceErrAt = 0L
    private val hist = mutableListOf<Pair<String, String>>()

    fun init(c: Context) {
        if (ready) return
        ready = true
        app = c.applicationContext
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { Prefs.set(app, "last_crash", Date().toString() + "\n" + e.stackTraceToString().take(1800)) } catch (_: Exception) {}
            prev?.uncaughtException(t, e)
        }
        Voice.init(app)
        Voice.onIdle = {
            lastActivity = System.currentTimeMillis()
            followUntil = lastActivity + 9000
            main.post { if (!busy) listen() }
        }
        Voice.onError = { m ->
            val now = System.currentTimeMillis()
            if (m != lastVoiceErr || now - lastVoiceErrAt > 30000) {
                lastVoiceErr = m; lastVoiceErrAt = now
                addChat(false, "🔇 Awaaz nahi aa pa rahi: $m")
            }
        }
    }

    private fun fail(e: Throwable) {
        try { Prefs.set(app, "last_err", Date().toString() + "\n" + e.stackTraceToString().take(1500)) } catch (_: Exception) {}
        addChat(false, "⚠ Error: ${e.message}")
        busy = false
        state.value = "IDLE"
        main.post { listen() }
    }

    private fun addChat(user: Boolean, t: String) { chat.value = (chat.value + (user to t)).takeLast(60) }

    fun L(hi: String, en: String): String = if (Prefs.get(app, "rlang", "hi") == "en") en else hi

    private fun sys(): String {
        val name = Prefs.get(app, "uname").trim()
        val lang = when (Prefs.get(app, "rlang", "hi")) {
            "en" -> "Always talk in casual English, whatever language the user speaks."
            "auto" -> "Talk in the same language the user speaks (Hindi in Devanagari)."
            else -> "ALWAYS talk in Hindi/Hinglish written in Devanagari script, whatever language the user speaks."
        }
        return PERSONA + "\n" + (if (name.isNotBlank()) "The user's name is $name; call them $name or 'भाई'.\n" else "Call the user 'भाई'.\n") +
            "LANGUAGE: " + lang + "\n" + SYS + "\nCurrent time: " + Date()
    }

    fun stopSpeaking() { Voice.stop(); main.post { listen() } }

    private fun stripWake(t: String): String? {
        val low = t.lowercase()
        val w = listOf("hey jarvis", "jarvis", "जार्विस", "जारविस", "जर्विस", "हे जार्विस").firstOrNull { low.contains(it) } ?: return null
        return t.substring(low.indexOf(w) + w.length).trim(' ', ',', '.')
    }

    private fun greet() {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val n = Prefs.get(app, "uname").trim().ifBlank { "भाई" }
        val s = when {
            h in 5..11 -> L("सुबह-सुबह! उठ गया $n? आज का क्या प्लान है?", "Morning $n! What's the plan today?")
            h in 12..16 -> L("अरे $n, क्या चल रहा है? खाना खाया कुछ?", "Hey $n, what's up? Had lunch?")
            h in 17..21 -> L("और $n, दिन कैसा रहा आज?", "Hey $n, how was your day?")
            else -> L("अरे $n, अभी तक जाग रहा है? क्या चल रहा है?", "Hey $n, still awake? What's going on?")
        }
        addChat(false, s); reply.value = s; state.value = "ASSIST"
        Voice.say(s)
    }

    private val idleCheck = object : Runnable {
        override fun run() {
            if (!listening.value) return
            val gap = (Prefs.get(app, "idle", "180").toLongOrNull() ?: 180L) * 1000
            if (Prefs.get(app, "proactive", "1") == "1" && gap > 0 && !busy && !Voice.busy && nudges < 3 &&
                System.currentTimeMillis() - lastActivity > gap) {
                nudges++
                lastActivity = System.currentTimeMillis()
                busy = true
                state.value = "THINK"
                sr?.cancel()
                scope.launch { try { process("[SYSTEM EVENT: the user has been quiet for a while. Start a short, natural, friendly chat like a close friend would: ask how they are, what they are doing, or share one small fun thought. 1-2 short sentences. Do NOT mention this event and do NOT use any phone action.]", true) } finally { finish() } }
            }
            main.postDelayed(this, 15000)
        }
    }

    fun start() {
        val first = !listening.value
        listening.value = true
        nudges = 0
        lastActivity = System.currentTimeMillis()
        main.removeCallbacks(idleCheck)
        main.postDelayed(idleCheck, 15000)
        if (first && Prefs.get(app, "greet", "1") == "1") greet() else main.post { listen() }
    }

    fun stop() {
        listening.value = false
        main.removeCallbacks(idleCheck)
        main.post {
            sr?.destroy(); sr = null
            Voice.stop(); busy = false
            state.value = "IDLE"
            Overlay.hide()
        }
    }

    fun test() { scope.launch { Voice.say("नमस्ते भाई, मैं जार्विस हूँ। ये मेरी अपनी आवाज़ है।") } }

    fun sendText(t: String) {
        if (busy || t.isBlank()) return
        val cmd = stripWake(t) ?: t
        nudges = 0
        lastActivity = System.currentTimeMillis()
        heard.value = t
        busy = true
        state.value = "THINK"
        scope.launch {
            try { if (cmd.isBlank()) { addChat(true, t); say(L("हाँ भाई, बोल", "Yeah, tell me")) } else process(cmd) } finally { finish() }
        }
    }

    private fun listen() {
        if (!listening.value || busy || Voice.busy) return
        if (sr == null) {
            sr = SpeechRecognizer.createSpeechRecognizer(app).also { r ->
                r.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(p: Bundle?) { state.value = "LISTENING" }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(v: Float) { level.value = ((v + 2f) / 12f).coerceIn(0f, 1f) }
                    override fun onBufferReceived(b: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onError(e: Int) { sr?.cancel(); main.postDelayed({ listen() }, 350) }
                    override fun onResults(r: Bundle?) {
                        handle(r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: "")
                    }
                    override fun onPartialResults(p: Bundle?) {
                        p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { heard.value = it }
                    }
                    override fun onEvent(t: Int, p: Bundle?) {}
                })
            }
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.get(app, "lang", "hi-IN"))
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 700L)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 500L)
        try { sr?.startListening(i) } catch (e: Exception) { main.postDelayed({ listen() }, 800) }
    }

    private fun handle(t: String) {
        if (t.isBlank() || busy) { listen(); return }
        var cmd = t
        val w = stripWake(t)
        if (w != null) cmd = w
        else if (Prefs.get(app, "wake2", "0") == "1" && System.currentTimeMillis() > followUntil) { listen(); return }
        if (cmd.isNotBlank() && cmd.length < 2) { listen(); return }
        nudges = 0
        lastActivity = System.currentTimeMillis()
        heard.value = t
        busy = true
        state.value = "THINK"
        scope.launch {
            try { if (cmd.isBlank()) { addChat(true, t); say(L("हाँ भाई, बोल", "Yeah, tell me")) } else process(cmd) } finally { finish() }
        }
    }

    private fun finish() {
        busy = false
        main.post { if (!Voice.busy) listen() }
    }

    private fun extractSay(a: String): String {
        val i = a.indexOf("\"say\"")
        if (i < 0) return ""
        var k = a.indexOf(':', i + 5)
        if (k < 0) return ""
        k = a.indexOf('"', k + 1)
        if (k < 0) return ""
        val sb = StringBuilder()
        var j = k + 1
        while (j < a.length) {
            val ch = a[j]
            if (ch == '\\') {
                if (j + 1 >= a.length) break
                val n = a[j + 1]
                if (n == 'u') {
                    if (j + 6 > a.length) break
                    try { sb.append(a.substring(j + 2, j + 6).toInt(16).toChar()) } catch (e: Exception) { break }
                    j += 6
                } else {
                    sb.append(when (n) { 'n', 't' -> ' '; else -> n })
                    j += 2
                }
            } else if (ch == '"') break
            else { sb.append(ch); j++ }
        }
        return sb.toString()
    }

    private fun sentenceEnd(s: String, from: Int): Int {
        var end = from
        for (i in from until s.length - 1) if (s[i] in ".?!।" && s[i + 1].isWhitespace()) end = i + 1
        if (end == from && s.length - from > 45) {
            val c = s.lastIndexOf(", ")
            if (c > from + 20) end = c + 1
        }
        return end
    }

    private fun speakPart(t: String) { state.value = "ASSIST"; Voice.say(t) }

    private suspend fun process(cmd: String, silent: Boolean = false) {
        if (!silent) {
            addChat(true, cmd)
            val q = Quick.match(app, cmd)
            if (q != null) { state.value = "EXECUTE"; if (q.first.isNotBlank()) say(q.first); q.second(); return }
            if (Prefs.get(app, "echo", "0") == "1") Voice.say("आपने कहा: $cmd")
        }
        hist.add("user" to cmd)
        var saidAny = false
        for (step in 0 until 12) {
            state.value = "PROCESS"
            var spoken = 0
            val txt = try {
                withContext(Dispatchers.IO) {
                    Ai.chat(app, sys(), hist) { acc ->
                        val s = extractSay(acc)
                        if (s.length > spoken) reply.value = s
                        val end = sentenceEnd(s, spoken)
                        if (end > spoken) {
                            val piece = s.substring(spoken, end).trim()
                            spoken = end
                            if (piece.isNotBlank()) speakPart(piece)
                        }
                    }
                }
            } catch (e: Exception) {
                reply.value = "⚠ ${e.message}"
                addChat(false, "⚠ ${e.message}")
                state.value = "ASSIST"
                if (!silent) Voice.say(L("अरे यार, एआई से जवाब नहीं आया। सेटिंग्स में की टेस्ट कर ले।", "Hey, the AI didn't answer. Test the key in settings."))
                hist.removeLastOrNull()
                return
            }
            hist.add("assistant" to txt)
            val j = parse(txt)
            val full = (if (txt.trim().startsWith("{")) extractSay(txt) else txt).ifBlank { j.optString("say") }.trim()
            if (spoken < full.length) {
                val rest = full.substring(spoken).trim()
                if (rest.isNotBlank()) speakPart(rest)
            }
            if (full.isNotBlank()) { addChat(false, full); reply.value = full; saidAny = true }
            if (silent) break
            state.value = "EXECUTE"
            var obs = ""
            val d = j.optJSONArray("do")
            if (d != null) for (k in 0 until d.length()) {
                val o = d.optJSONObject(k) ?: continue
                obs += Act.run(app, o.optString("a"), o.optString("x"), o.optString("y"))
            }
            if (obs.isBlank()) break
            hist.add("user" to "OBSERVATION: " + obs.take(2500))
        }
        if (!saidAny && !silent) say(L("ठीक है भाई, हो गया", "Done, bro"))
        if (hist.isNotEmpty() && hist.last().first == "user") hist.add("assistant" to "{}")
        while (hist.size > 16) hist.removeAt(0)
        while (hist.isNotEmpty() && hist[0].first != "user") hist.removeAt(0)
    }

    private fun parse(t: String): JSONObject = try {
        JSONObject(t.substring(t.indexOf('{'), t.lastIndexOf('}') + 1))
    } catch (e: Exception) { JSONObject().put("say", t) }

    private fun say(s: String) { reply.value = s; addChat(false, s); speakPart(s) }
}
