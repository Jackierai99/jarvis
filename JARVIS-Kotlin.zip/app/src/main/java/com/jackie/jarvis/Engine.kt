package com.jackie.jarvis

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

private const val SYS = """You are JARVIS, a brilliant, witty and extremely capable voice assistant living inside the user's Android phone (like Tony Stark's JARVIS). You hear the user's voice and you control their phone.
Reply with ONLY one JSON object, no markdown: {"say":"spoken reply","do":[{"a":"action","x":"arg1","y":"arg2"}]}
Keep "say" very short (1-2 sentences) but fully correct. Never invent facts; if unsure, say so.
ACTIONS (a): open_app(x=app name in English as on phone, e.g. YouTube), call(x=contact name or number), sms(x=contact/number,y=text), whatsapp(x=contact/number,y=text), web(x=search query), youtube(x=search query), maps(x=place), alarm(x=HH:MM 24h,y=label), timer(x=seconds), torch(x=on|off), volume(x=up|down|mute|0-100), media(x=play|pause|next|prev), settings(x=wifi|bluetooth|display|sound|apps|location|main), global(x=back|home|recents|notifications|quick|screenshot|lock|power), click(x=visible text or description on screen), type(x=text into the focused box), scroll(x=up|down), read_screen (you then receive OBSERVATION with the visible screen text).
RULES: chain several actions in order in "do". For multi-step phone tasks (e.g. turn Wi-Fi on: global quick, then click Wi-Fi) do the steps, use read_screen to verify, and continue when you get an OBSERVATION. Do risky things (calls, messages) only when the user clearly asked. If no action is needed, "do":[]."""

object Engine {
    private lateinit var app: Context
    private var ready = false
    val state = MutableStateFlow("IDLE")
    val heard = MutableStateFlow("")
    val reply = MutableStateFlow("")
    val listening = MutableStateFlow(false)
    val level = MutableStateFlow(0f)
    val chat = MutableStateFlow<List<Pair<Boolean, String>>>(emptyList())

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsOk = false
    private var ttsWarned = false
    private val pending = AtomicInteger(0)
    @Volatile private var busy = false
    private val hist = mutableListOf<Pair<String, String>>()

    fun init(c: Context) {
        if (ready) return
        ready = true
        app = c.applicationContext
        tts = TextToSpeech(app) { ok ->
            ttsOk = ok == TextToSpeech.SUCCESS
            if (ttsOk) {
                tts?.setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { fin() }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) {}
                    override fun onError(id: String?, code: Int) { addChat(false, "🔇 Voice error $code (Settings me Voice engine check karo)"); fin() }
                })
            }
        }
    }

    private fun addChat(user: Boolean, t: String) { chat.value = (chat.value + (user to t)).takeLast(60) }

    fun L(hi: String, en: String): String = if (Prefs.get(app, "rlang", "hi") == "en") en else hi

    private fun hiOk(): Boolean = (tts?.isLanguageAvailable(Locale("hi", "IN")) ?: -2) >= 0

    private fun sys(): String {
        val lang = when (Prefs.get(app, "rlang", "hi")) {
            "en" -> "Always reply in English, whatever language the user speaks."
            "auto" -> "Reply in the same language the user speaks." + if (hiOk()) " If that is Hindi or Hinglish, write in Devanagari." else " If that is Hindi or Hinglish, write Hindi in Roman letters."
            else -> if (hiOk()) "ALWAYS reply in Hindi written in Devanagari script, whatever language the user speaks." else "ALWAYS reply in Hindi written in Roman letters (Hinglish), whatever language the user speaks."
        }
        return SYS + "\nLANGUAGE: " + lang + "\nCurrent time: " + Date()
    }

    fun stopSpeaking() { tts?.stop(); pending.set(0) }

    /** wake word hatao. null = wake word nahi mila */
    private fun stripWake(t: String): String? {
        val low = t.lowercase()
        val w = listOf("hey jarvis", "jarvis", "जार्विस", "जारविस", "जर्विस", "हे जार्विस").firstOrNull { low.contains(it) } ?: return null
        return t.substring(low.indexOf(w) + w.length).trim(' ', ',', '.')
    }

    private fun fin() {
        if (pending.decrementAndGet() <= 0) {
            pending.set(0)
            main.post { if (!busy) listen() }
        }
    }

    fun start() { listening.value = true; main.post { listen() } }

    fun stop() {
        listening.value = false
        main.post {
            sr?.destroy(); sr = null
            tts?.stop(); pending.set(0); busy = false
            state.value = "IDLE"
        }
    }

    /** Settings se aawaz sunne ke liye */
    fun test() { main.post { speak(if (hiOk()) "नमस्ते, मैं जार्विस हूँ। मेरी आवाज़ ऐसी है।" else "Namaste, main Jarvis hoon. Meri awaaz aisi hai.", true) } }

    /** Typed command (keyboard se) */
    fun sendText(t: String) {
        if (busy || t.isBlank()) return
        val cmd = stripWake(t) ?: t
        heard.value = t
        busy = true
        state.value = "THINK"
        scope.launch {
            try { if (cmd.isBlank()) { addChat(true, t); say(L("जी, बोलिए", "Yes, I'm listening")) } else run(cmd) } finally { finish() }
        }
    }

    private fun listen() {
        if (!listening.value || busy || pending.get() > 0) return
        if (sr == null) {
            sr = SpeechRecognizer.createSpeechRecognizer(app).also { r ->
                r.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(p: Bundle?) { state.value = "LISTENING" }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(v: Float) { level.value = ((v + 2f) / 12f).coerceIn(0f, 1f) }
                    override fun onBufferReceived(b: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onError(e: Int) { sr?.cancel(); main.postDelayed({ listen() }, 400) }
                    override fun onResults(r: Bundle?) {
                        handle(r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: "")
                    }
                    override fun onPartialResults(p: Bundle?) {
                        p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { heard.value = it }
                    }
                    override fun onEvent(t: Int, p: Bundle?) {}
                })
            }
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.get(app, "lang", "hi-IN"))
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 800L)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 600L)
        try { sr?.startListening(i) } catch (e: Exception) { main.postDelayed({ listen() }, 800) }
    }

    private fun handle(t: String) {
        if (t.isBlank() || busy) { listen(); return }
        var cmd = t
        if (Prefs.get(app, "wake", "1") == "1") {
            val w = stripWake(t)
            if (w == null) { listen(); return }
            cmd = w
        }
        heard.value = t
        busy = true
        state.value = "THINK"
        scope.launch {
            try { if (cmd.isBlank()) { addChat(true, t); say(L("जी, बोलिए", "Yes, I'm listening")) } else run(cmd) } finally { finish() }
        }
    }

    private fun finish() {
        busy = false
        main.post { if (pending.get() == 0) listen() }
    }

    private suspend fun run(cmd: String) {
        addChat(true, cmd)
        val q = Quick.match(app, cmd)
        if (q != null) { state.value = "EXECUTE"; if (q.first.isNotBlank()) say(q.first); q.second(); return }
        if (Prefs.get(app, "echo", "0") == "1") speak("आपने कहा: $cmd")
        hist.add("user" to cmd)
        for (step in 0 until 4) {
            state.value = "PROCESS"
            val txt = try {
                withContext(Dispatchers.IO) { Ai.chat(app, sys(), hist) }
            } catch (e: Exception) {
                reply.value = "⚠ ${e.message}"
                addChat(false, "⚠ ${e.message}")
                state.value = "ASSIST"
                speak(L("एआई से जवाब नहीं आया, सेटिंग्स में की टेस्ट करें", "No reply from AI. Please test the key in settings."))
                hist.removeLastOrNull()
                return
            }
            hist.add("assistant" to txt)
            val j = parse(txt)
            state.value = "EXECUTE"
            val s = j.optString("say")
            if (s.isNotBlank()) say(s)
            var obs = ""
            val d = j.optJSONArray("do")
            if (d != null) for (k in 0 until d.length()) {
                val o = d.optJSONObject(k) ?: continue
                obs += Act.run(app, o.optString("a"), o.optString("x"), o.optString("y"))
            }
            if (obs.isBlank()) break
            hist.add("user" to "OBSERVATION: $obs")
        }
        if (hist.last().first == "user") hist.add("assistant" to "{}")
        while (hist.size > 14) hist.removeAt(0)
        while (hist.isNotEmpty() && hist[0].first != "user") hist.removeAt(0)
    }

    private fun parse(t: String): JSONObject = try {
        JSONObject(t.substring(t.indexOf('{'), t.lastIndexOf('}') + 1))
    } catch (e: Exception) { JSONObject().put("say", t) }

    private fun say(s: String) { reply.value = s; addChat(false, s); state.value = "ASSIST"; speak(s) }

    private fun applyVoice(hi: Boolean) {
        val t = tts ?: return
        val r = t.setLanguage(if (hi) Locale("hi", "IN") else Locale("en", "IN"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) t.setLanguage(Locale.getDefault())
        val i = (Prefs.get(app, "voice", "0").toIntOrNull() ?: 0).coerceIn(0, 5)
        t.setPitch(floatArrayOf(1.25f, 1.4f, 1.1f, 0.8f, 0.68f, 0.92f)[i])
        t.setSpeechRate(floatArrayOf(1.0f, 1.1f, 0.95f, 1.0f, 0.9f, 1.1f)[i])
    }

    private var volWarned = false
    private var hiWarned = false

    private fun speak(t: String, force: Boolean = false) {
        if (!force && Prefs.get(app, "voice_on", "1") == "0") return
        if (!ttsOk) {
            if (!ttsWarned) {
                ttsWarned = true
                addChat(false, "🔇 Voice engine nahi mila. Phone Settings → Text-to-speech me Google TTS ON karo.")
            }
            return
        }
        if (!hiOk() && !hiWarned && Prefs.get(app, "rlang", "hi") != "en") {
            hiWarned = true
            addChat(false, "ℹ Hindi voice data nahi hai. Settings → Voice engine se Hindi download karo. Tab tak Hinglish me bolunga.")
        }
        val am = app.getSystemService(android.media.AudioManager::class.java)
        if (am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC) == 0 && !volWarned) {
            volWarned = true
            addChat(false, "🔈 Media volume 0 hai, volume badhao tab awaaz aayegi.")
        }
        applyVoice(t.any { it in '\u0900'..'\u097F' })
        pending.incrementAndGet()
        if (tts?.speak(t, TextToSpeech.QUEUE_ADD, null, "u" + System.nanoTime()) != TextToSpeech.SUCCESS) pending.decrementAndGet()
    }
}
