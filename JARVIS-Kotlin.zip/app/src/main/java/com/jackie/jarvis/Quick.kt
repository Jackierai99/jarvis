package com.jackie.jarvis

import android.content.Context

/** Common commands bina AI ke turant chalte hain (instant). */
object Quick {
    private val apps = mapOf(
        "यूट्यूब" to "YouTube", "युटुब" to "YouTube", "यू ट्यूब" to "YouTube", "यूटूब" to "YouTube", "youtube" to "YouTube",
        "क्रोम" to "Chrome", "chrome" to "Chrome", "कैमरा" to "Camera", "camera" to "Camera",
        "व्हाट्सएप" to "WhatsApp", "व्हाट्सऐप" to "WhatsApp", "वाट्सएप" to "WhatsApp", "whatsapp" to "WhatsApp",
        "इंस्टाग्राम" to "Instagram", "instagram" to "Instagram", "फेसबुक" to "Facebook", "facebook" to "Facebook",
        "टेलीग्राम" to "Telegram", "telegram" to "Telegram", "गैलरी" to "Gallery", "gallery" to "Gallery",
        "सेटिंग" to "Settings", "settings" to "Settings", "प्ले स्टोर" to "Play Store", "play store" to "Play Store",
        "स्पॉटिफाई" to "Spotify", "spotify" to "Spotify", "मैप" to "Maps", "maps" to "Maps",
        "कैलकुलेटर" to "Calculator", "calculator" to "Calculator", "घड़ी" to "Clock", "clock" to "Clock"
    )
    private val verbs = listOf("खोल", "चला", "चालू", "स्टार्ट", "open", "start", "launch", "kholo", "khol", "chalao", "chala")

    fun match(app: Context, cmd: String): Pair<String, () -> Unit>? {
        val c = cmd.lowercase().trim()
        if (c.split(Regex("\\s+")).size > 5) return null
        if (verbs.any { c.contains(it) }) {
            val name = apps.entries.firstOrNull { c.contains(it.key) }?.value
            if (name != null) return "ठीक है, $name खोल रहा हूँ" to { Act.run(app, "open_app", name, ""); Unit }
        }
        val off = c.contains("बंद") || c.contains("off") || c.contains("band")
        if (c.contains("टॉर्च") || c.contains("torch") || c.contains("flashlight") || c.contains("टार्च"))
            return (if (off) "टॉर्च बंद" else "टॉर्च चालू") to { Act.run(app, "torch", if (off) "off" else "on", ""); Unit }
        if (c.contains("screenshot") || c.contains("स्क्रीनशॉट"))
            return "स्क्रीनशॉट ले रहा हूँ" to { Act.run(app, "global", "screenshot", ""); Unit }
        return null
    }
}
