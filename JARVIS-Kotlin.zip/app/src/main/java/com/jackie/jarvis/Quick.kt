package com.jackie.jarvis

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Common commands bina AI ke turant chalte hain (instant). */
object Quick {
    private val apps = mapOf(
        "यूट्यूब" to "YouTube", "युटुब" to "YouTube", "यू ट्यूब" to "YouTube", "यूटूब" to "YouTube", "youtube" to "YouTube",
        "क्रोम" to "Chrome", "chrome" to "Chrome", "कैमरा" to "Camera", "camera" to "Camera",
        "व्हाट्सएप" to "WhatsApp", "व्हाट्सऐप" to "WhatsApp", "वाट्सएप" to "WhatsApp", "whatsapp" to "WhatsApp",
        "इंस्टाग्राम" to "Instagram", "instagram" to "Instagram", "फेसबुक" to "Facebook", "facebook" to "Facebook",
        "टेलीग्राम" to "Telegram", "telegram" to "Telegram", "गैलरी" to "Gallery", "gallery" to "Gallery",
        "सेटिंग" to "Settings", "settings" to "Settings", "प्ले स्टोर" to "Play Store", "play store" to "Play Store",
        "स्पॉटिफाई" to "Spotify", "spotify" to "Spotify", "मैप" to "Maps", "maps" to "Maps",
        "कैलकुलेटर" to "Calculator", "calculator" to "Calculator", "घड़ी" to "Clock", "clock" to "Clock"
    )
    private val verbs = listOf("खोल", "चला", "चालू", "स्टार्ट", "open", "start", "launch", "kholo", "khol", "chalao", "chala")

    private fun has(c: String, vararg w: String) = w.any { c.contains(it) }

    fun match(app: Context, cmd: String): Pair<String, () -> Unit>? {
        val c = cmd.lowercase().trim()
        if (c.split(Regex("\\s+")).size > 5) return null
        val L = { hi: String, en: String -> Engine.L(hi, en) }
        if (verbs.any { c.contains(it) }) {
            val name = apps.entries.firstOrNull { c.contains(it.key) }?.value
            if (name != null) return L("ठीक है, $name खोल रहा हूँ", "Opening $name") to { Act.run(app, "open_app", name, ""); Unit }
        }
        val off = has(c, "बंद", "off", "band")
        if (has(c, "टॉर्च", "torch", "flashlight", "टार्च"))
            return (if (off) L("टॉर्च बंद", "Torch off") else L("टॉर्च चालू", "Torch on")) to { Act.run(app, "torch", if (off) "off" else "on", ""); Unit }
        if (has(c, "screenshot", "स्क्रीनशॉट"))
            return L("स्क्रीनशॉट ले रहा हूँ", "Taking a screenshot") to { Act.run(app, "global", "screenshot", ""); Unit }
        if (has(c, "कितने बजे", "टाइम", "time", "समय", "baje")) {
            val t = SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date())
            return L("अभी $t हो रहे हैं", "It's $t") to {}
        }
        if (has(c, "तारीख", "date", "आज कौन सा दिन", "कौन सा दिन")) {
            val d = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH).format(Date())
            return L("आज $d है", "Today is $d") to {}
        }
        if (has(c, "बैटरी", "battery")) {
            val b = app.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val p = b?.let { it.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / it.getIntExtra(BatteryManager.EXTRA_SCALE, 100) } ?: 0
            return L("बैटरी $p प्रतिशत है", "Battery is at $p percent") to {}
        }
        if (has(c, "volume", "वॉल्यूम", "आवाज़", "आवाज"))
            when {
                has(c, "बढ़ा", "badha", "up", "increase", "ज्यादा", "ज़्यादा", "तेज़", "तेज") ->
                    return L("आवाज़ बढ़ा रहा हूँ", "Volume up") to { Act.run(app, "volume", "up", ""); Unit }
                has(c, "कम", "घटा", "down", "decrease", "dheere", "धीरे") ->
                    return L("आवाज़ कम कर रहा हूँ", "Volume down") to { Act.run(app, "volume", "down", ""); Unit }
            }
        if (has(c, "वापस", "पीछे", "back")) return L("ठीक है", "Okay") to { Act.run(app, "global", "back", ""); Unit }
        if (c == "home" || has(c, "होम", "go home")) return L("होम स्क्रीन", "Going home") to { Act.run(app, "global", "home", ""); Unit }
        if (has(c, "recent", "रीसेंट")) return L("ठीक है", "Okay") to { Act.run(app, "global", "recents", ""); Unit }
        if (has(c, "notification", "नोटिफिकेशन")) return L("नोटिफिकेशन खोल रहा हूँ", "Opening notifications") to { Act.run(app, "global", "notifications", ""); Unit }
        if (has(c, "चुप", "रुको", "stop", "shut up")) return "" to { Engine.stopSpeaking() }
        return null
    }
}
