package com.jackie.jarvis

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Cy = Color(0xFF00E5FF)
val Dim = Color(0xFF8FDFFF)

@Composable
fun Orb(lv: Float, st: String, on: Boolean) {
    val tr = rememberInfiniteTransition(label = "o")
    val a by tr.animateFloat(0f, 360f, infiniteRepeatable(tween(12000, easing = LinearEasing)), label = "a")
    val pulse by animateFloatAsState(if (on) lv else 0f, label = "p")
    val working = st == "THINK" || st == "PROCESS" || st == "EXECUTE"
    Box(Modifier.fillMaxWidth().height(250.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(250.dp)) {
            val c = center
            val r = size.minDimension / 2
            drawCircle(Brush.radialGradient(listOf(Cy.copy(alpha = .22f + pulse * .35f), Color.Transparent), c, r), r, c)
            for (k in 0..2) {
                val rr = r * (0.66f + k * 0.1f) + pulse * 6f * (k + 1)
                drawArc(
                    color = Cy.copy(alpha = .85f - k * .2f),
                    startAngle = (if (k % 2 == 0) a else -a * 1.5f) + k * 70f,
                    sweepAngle = if (working) 200f else 110f,
                    useCenter = false,
                    topLeft = Offset(c.x - rr, c.y - rr),
                    size = Size(rr * 2, rr * 2),
                    style = Stroke(width = 4f + k * 1.5f, cap = StrokeCap.Round)
                )
            }
        }
        Image(
            painter = painterResource(R.drawable.logo),
            contentDescription = "JARVIS",
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(150.dp).graphicsLayer { scaleX = 1f + pulse * .08f; scaleY = 1f + pulse * .08f }.clip(CircleShape)
        )
    }
}

@Composable
fun Bubble(m: Pair<Boolean, String>) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.first) Arrangement.End else Arrangement.Start) {
        Text(
            m.second, color = Color.White, fontSize = 14.sp,
            modifier = Modifier.widthIn(max = 290.dp).clip(RoundedCornerShape(14.dp))
                .background(if (m.first) Color(0x6600B8FF) else Color(0xCC001A33))
                .border(1.dp, Cy.copy(alpha = .35f), RoundedCornerShape(14.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp)
        )
    }
}

@Composable
fun Hud(onMic: () -> Unit, onSettings: () -> Unit) {
    val st by Engine.state.collectAsState()
    val on by Engine.listening.collectAsState()
    val lv by Engine.level.collectAsState()
    val chat by Engine.chat.collectAsState()
    val heard by Engine.heard.collectAsState()
    var text by remember { mutableStateOf("") }
    val ls = rememberLazyListState()
    LaunchedEffect(chat.size) { if (chat.isNotEmpty()) ls.animateScrollToItem(chat.size - 1) }
    val status = if (!on) "Mic dabao ya type karo" else when (st) {
        "THINK" -> "Thinking..."; "PROCESS" -> "Processing..."; "EXECUTE" -> "Executing..."; "ASSIST" -> "Speaking..."
        else -> if (heard.isNotBlank() && st == "LISTENING") "🗣 $heard" else "I'm listening... say \"Hey JARVIS\""
    }
    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF000814), Color(0xFF001A33), Color(0xFF000814)))).padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("J.A.R.V.I.S", color = Color.White, fontSize = 22.sp, letterSpacing = 4.sp)
                Text("JUST A RATHER VERY INTELLIGENT SYSTEM", color = Cy, fontSize = 8.sp)
            }
            TextButton(onClick = onSettings) { Text("⚙", fontSize = 24.sp) }
        }
        Orb(lv, st, on)
        Text(status, color = Cy, fontSize = 14.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = ls, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(chat) { m -> Bubble(m) }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("YouTube kholo", "Torch on", "Abhi time kya hai?", "Ek joke sunao", "Screenshot lo").forEach {
                Text(it, color = Dim, fontSize = 12.sp, modifier = Modifier.clip(RoundedCornerShape(16.dp)).border(1.dp, Cy.copy(alpha = .4f), RoundedCornerShape(16.dp)).clickable { Engine.sendText(it) }.padding(horizontal = 12.dp, vertical = 6.dp))
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
                Modifier.size(54.dp).clip(CircleShape).background(if (on) Cy else Color(0xFF002A4D)).border(1.dp, Cy, CircleShape).clickable { onMic() },
                contentAlignment = Alignment.Center
            ) { Text("🎙", fontSize = 24.sp) }
            OutlinedTextField(
                value = text, onValueChange = { text = it }, singleLine = true, modifier = Modifier.weight(1f),
                placeholder = { Text("Command likho...") }
            )
            Button(onClick = { if (text.isNotBlank()) { Engine.sendText(text.trim()); text = "" } }) { Text("➤") }
        }
    }
}

@Composable
fun PrefField(k: String, label: String, secret: Boolean = false) {
    val c = LocalContext.current
    var v by remember { mutableStateOf(Prefs.get(c, k)) }
    OutlinedTextField(
        value = v, onValueChange = { v = it; Prefs.set(c, k, it) }, label = { Text(label) }, singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        supportingText = {
            if (secret && v.isNotBlank() && !v.trim().startsWith("AIza")) Text("⚠ Gemini key aksar AIza se shuru hoti hai (aistudio.google.com/apikey)")
        }
    )
}

@Composable
fun PrefSwitch(k: String, label: String, def: String) {
    val c = LocalContext.current
    var v by remember { mutableStateOf(Prefs.get(c, k, def) == "1") }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f))
        Switch(checked = v, onCheckedChange = { v = it; Prefs.set(c, k, if (it) "1" else "0") })
    }
}

@Composable
fun SettingsScreen(onClose: () -> Unit) {
    val c = LocalContext.current
    var lang by remember { mutableStateOf(Prefs.get(c, "lang", "hi-IN")) }
    var voice by remember { mutableStateOf(Prefs.get(c, "voice", "0").toIntOrNull() ?: 0) }
    val voices = listOf("👧 Girl 1", "👧 Girl 2", "👧 Girl 3", "👦 Boy 1", "👦 Boy 2", "👦 Boy 3")
    Column(
        Modifier.fillMaxSize().background(Color(0xFF000814)).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("SETTINGS", color = Cy, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = onClose) { Text("✕ CLOSE") }
        }
        PrefField("key_gemini", "Gemini API key", true)
        PrefField("model_gemini", "Gemini model (optional)")
        Text("JARVIS ki aawaz", color = Dim, fontSize = 12.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            voices.forEachIndexed { i, n ->
                FilterChip(selected = voice == i, onClick = { voice = i; Prefs.set(c, "voice", i.toString()) }, label = { Text(n) })
            }
        }
        Button(onClick = { Engine.init(c); Engine.test() }, modifier = Modifier.fillMaxWidth()) { Text("🔊 Aawaz test karo") }
        Button(onClick = { c.startActivity(Intent("com.android.settings.TTS_SETTINGS")) }, modifier = Modifier.fillMaxWidth()) { Text("Voice engine / Hindi voice data (Phone settings)") }
        Text("Bolne ki language", color = Dim, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("hi-IN", "en-IN").forEach { l -> FilterChip(selected = lang == l, onClick = { lang = l; Prefs.set(c, "lang", l) }, label = { Text(l) }) }
        }
        PrefSwitch("wake", "Wake word \"Hey JARVIS\" zaroori", "1")
        PrefSwitch("echo", "Meri bat repeat karke bolo (thoda slow)", "0")
        Text("Phone control setup", color = Dim, fontSize = 12.sp)
        Button(onClick = { c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) { Text("1. Accessibility ON karo (JARVIS)") }
        Button(onClick = { c.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + c.packageName))) }, modifier = Modifier.fillMaxWidth()) { Text("2. Display over other apps allow") }
        Button(onClick = { c.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) { Text("3. Battery: JARVIS ko unrestricted karo") }
    }
}
