package com.jackie.jarvis

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

val Cy = Color(0xFF00E5FF)
val Dim = Color(0xFF8FDFFF)
val Pn = Color(0xCC001A33)

@Composable
fun Panel(mod: Modifier = Modifier, title: String? = null, body: @Composable ColumnScope.() -> Unit) {
    Column(mod.clip(RoundedCornerShape(8.dp)).background(Pn).border(1.dp, Cy.copy(alpha = .55f), RoundedCornerShape(8.dp)).padding(10.dp)) {
        if (title != null) Text(title, color = Cy, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp))
        body()
    }
}

fun readSys(c: Context): List<Int> {
    val am = c.getSystemService(ActivityManager::class.java)
    val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
    val ram = (100 - mi.availMem * 100 / mi.totalMem).toInt()
    val sf = StatFs(Environment.getDataDirectory().path)
    val st = (100 - sf.availableBytes * 100 / sf.totalBytes).toInt()
    val b = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val bat = b?.let { it.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / it.getIntExtra(BatteryManager.EXTRA_SCALE, 100) } ?: 0
    val tmp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10
    return listOf(tmp, ram, st, bat)
}

@Composable
fun Bar(label: String, text: String, pct: Int) {
    Column(Modifier.padding(vertical = 3.dp)) {
        Row { Text(label, color = Dim, fontSize = 11.sp, modifier = Modifier.weight(1f)); Text(text, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
        LinearProgressIndicator(progress = { pct.coerceIn(0, 100) / 100f }, modifier = Modifier.fillMaxWidth(), color = Cy, trackColor = Color(0x3300E5FF))
    }
}

@Composable
fun Core(st: String, on: Boolean) {
    val tr = rememberInfiniteTransition(label = "core")
    val a by tr.animateFloat(0f, 360f, infiniteRepeatable(tween(14000, easing = LinearEasing)), label = "a")
    val hot = on && st != "IDLE"
    Box(Modifier.fillMaxWidth().height(270.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(260.dp)) {
            val c = center
            val r = size.minDimension / 2
            for (k in 0..3) {
                val rr = r * (0.62f + k * 0.12f)
                drawArc(
                    color = Cy.copy(alpha = 0.9f - k * 0.18f),
                    startAngle = (if (k % 2 == 0) a else -a) + k * 50f,
                    sweepAngle = 100f + k * 40f,
                    useCenter = false,
                    topLeft = Offset(c.x - rr, c.y - rr),
                    size = Size(rr * 2, rr * 2),
                    style = Stroke(width = 4f + k, cap = StrokeCap.Round)
                )
            }
            drawCircle(Brush.radialGradient(listOf(Cy.copy(alpha = if (hot) .4f else .2f), Color.Transparent), c, r * 0.75f), r * 0.75f, c)
        }
        Image(
            painter = painterResource(R.drawable.logo),
            contentDescription = "JARVIS",
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(156.dp).clip(CircleShape)
        )
    }
}

@Composable
fun Wave(lv: Float) {
    val ph by rememberInfiniteTransition(label = "w").animateFloat(0f, 6.28f, infiniteRepeatable(tween(900, easing = LinearEasing)), label = "p")
    Canvas(Modifier.height(40.dp).width(90.dp)) {
        for (i in 0 until 12) {
            val h = size.height * (0.12f + 0.88f * lv * abs(sin(ph + i * 0.7f)))
            val x = i * size.width / 12f + 3f
            drawLine(Cy, Offset(x, size.height / 2 - h / 2), Offset(x, size.height / 2 + h / 2), 3f, StrokeCap.Round)
        }
    }
}

@Composable
fun Hud(onMic: () -> Unit, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val st by Engine.state.collectAsState()
    val heard by Engine.heard.collectAsState()
    val rep by Engine.reply.collectAsState()
    val on by Engine.listening.collectAsState()
    val lv by Engine.level.collectAsState()
    var time by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    var sys by remember { mutableStateOf(listOf(0, 0, 0, 0)) }
    var wx by remember { mutableStateOf("--") }
    LaunchedEffect(Unit) {
        while (true) {
            val d = Date()
            time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(d)
            date = SimpleDateFormat("EEE, dd MMM yyyy", Locale.getDefault()).format(d)
            sys = readSys(ctx)
            delay(2000)
        }
    }
    LaunchedEffect(Unit) {
        wx = withContext(Dispatchers.IO) {
            try {
                val j = JSONObject(Ai.get("https://api.open-meteo.com/v1/forecast?latitude=28.61&longitude=77.21&current_weather=true")).getJSONObject("current_weather")
                "${j.getDouble("temperature").toInt()}°C"
            } catch (e: Exception) { "--" }
        }
    }
    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF000814), Color(0xFF001A33), Color(0xFF000814))))
            .verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("J.A.R.V.I.S", color = Color.White, fontSize = 22.sp, letterSpacing = 4.sp)
                Text("JUST A RATHER VERY INTELLIGENT SYSTEM", color = Cy, fontSize = 8.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(time, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text(date, color = Dim, fontSize = 10.sp)
                Text("$wx  New Delhi", color = Dim, fontSize = 10.sp)
            }
            TextButton(onClick = onSettings) { Text("⚙", fontSize = 22.sp) }
        }
        Core(st, on)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Panel(Modifier.weight(1f), "SYSTEM STATUS") {
                Bar("TEMP", "${sys[0]}°C", sys[0] * 2)
                Bar("RAM", "${sys[1]}%", sys[1])
                Bar("STORAGE", "${sys[2]}%", sys[2])
                Bar("BATTERY", "${sys[3]}%", sys[3])
            }
            Panel(Modifier.weight(1f), "VOICE COMMANDS") {
                listOf("open YouTube", "play music", "what's the weather?", "turn on torch", "take a screenshot", "call Mummy", "set alarm 7:30", "go home").forEach {
                    Text("› \"Hey JARVIS, $it\"", color = Dim, fontSize = 10.sp, modifier = Modifier.padding(vertical = 2.dp))
                }
            }
        }
        Panel(Modifier.fillMaxWidth(), "QUICK ACCESS") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("▶" to "YouTube", "🌐" to "Chrome", "🛍" to "Play Store", "📷" to "Camera", "🎵" to "Music", "🖼" to "Gallery").forEach { (e, n) ->
                    Column(
                        Modifier.weight(1f).clip(RoundedCornerShape(8.dp)).border(1.dp, Cy.copy(alpha = .4f), RoundedCornerShape(8.dp))
                            .clickable { Thread { Act.run(ctx, "open_app", n, "") }.start() }.padding(vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(e, fontSize = 20.sp)
                        Text(n, color = Dim, fontSize = 8.sp, textAlign = TextAlign.Center, maxLines = 1)
                    }
                }
            }
        }
        Panel(Modifier.fillMaxWidth(), "NOW PLAYING") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                listOf("⏮" to "prev", "⏯" to "play", "⏭" to "next").forEach { (e, a) ->
                    TextButton(onClick = { Thread { Act.run(ctx, "media", a, "") }.start() }) { Text(e, fontSize = 26.sp) }
                }
            }
        }
        Panel(Modifier.fillMaxWidth().clickable { onMic() }) {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceEvenly, modifier = Modifier.fillMaxWidth()) {
                    Wave(lv); Text("🎙", fontSize = 38.sp); Wave(lv)
                }
                Text(
                    if (!on) "Tap to activate JARVIS" else when (st) {
                        "THINK" -> "Thinking..."; "PROCESS" -> "Processing..."; "EXECUTE" -> "Executing..."; "ASSIST" -> "Speaking..."; else -> "I'm listening..."
                    }, color = Cy, fontSize = 18.sp, fontWeight = FontWeight.Bold
                )
                if (on) Text("Just say \"Hey JARVIS\"", color = Dim, fontSize = 11.sp)
                if (heard.isNotBlank()) Text("🗣 $heard", color = Color.White, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp))
                if (rep.isNotBlank()) Text("🤖 $rep", color = Cy, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp))
            }
        }
        Panel(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                listOf("🧠" to "THINK", "⚡" to "PROCESS", "🎯" to "EXECUTE", "😊" to "ASSIST").forEach { (e, n) ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(e, fontSize = if (st == n) 28.sp else 22.sp)
                        Text(n, color = if (st == n) Cy else Dim, fontSize = 10.sp, fontWeight = if (st == n) FontWeight.Bold else FontWeight.Normal)
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
fun PrefField(k: String, label: String, secret: Boolean = false) {
    val c = LocalContext.current
    var v by remember { mutableStateOf(Prefs.get(c, k)) }
    OutlinedTextField(
        value = v, onValueChange = { v = it; Prefs.set(c, k, it) }, label = { Text(label) }, singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None
    )
}

@Composable
fun PrefSwitch(k: String, label: String) {
    val c = LocalContext.current
    var v by remember { mutableStateOf(Prefs.get(c, k, "1") == "1") }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f))
        Switch(checked = v, onCheckedChange = { v = it; Prefs.set(c, k, if (it) "1" else "0") })
    }
}

@Composable
fun PrefChips(k: String, opts: List<String>, def: String) {
    val c = LocalContext.current
    var v by remember { mutableStateOf(Prefs.get(c, k, def)) }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        opts.forEach { o -> FilterChip(selected = v == o, onClick = { v = o; Prefs.set(c, k, o) }, label = { Text(o) }) }
    }
}

@Composable
fun SettingsScreen(onClose: () -> Unit) {
    val c = LocalContext.current
    Column(
        Modifier.fillMaxSize().background(Color(0xFF000814)).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("SETTINGS", color = Cy, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = onClose) { Text("✕ CLOSE") }
        }
        Text("AI provider (auto = jis jis ki key hai wo try hoga)", color = Dim, fontSize = 12.sp)
        PrefChips("provider", listOf("auto", "gemini", "claude", "openai"), "auto")
        PrefField("key_gemini", "Gemini API key", true)
        PrefField("model_gemini", "Gemini model (optional)")
        PrefField("key_claude", "Claude API key", true)
        PrefField("model_claude", "Claude model (optional)")
        PrefField("key_openai", "OpenAI API key (optional)", true)
        PrefField("model_openai", "OpenAI model (optional)")
        Text("Voice language", color = Dim, fontSize = 12.sp)
        PrefChips("lang", listOf("hi-IN", "en-IN"), "hi-IN")
        PrefSwitch("wake", "Wake word \"Hey JARVIS\" zaroori")
        PrefSwitch("echo", "Meri bat repeat karke bolo")
        Text("Phone control setup", color = Dim, fontSize = 12.sp)
        Button(onClick = { c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) { Text("1. Accessibility ON karo (JARVIS)") }
        Button(onClick = { c.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + c.packageName))) }, modifier = Modifier.fillMaxWidth()) { Text("2. Display over other apps allow") }
        Button(onClick = { c.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) { Text("3. Battery: JARVIS ko unrestricted karo") }
    }
}
