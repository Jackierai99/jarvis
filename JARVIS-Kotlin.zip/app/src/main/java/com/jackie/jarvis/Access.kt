package com.jackie.jarvis

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class JarvisAccess : AccessibilityService() {
    companion object { var inst: JarvisAccess? = null }

    override fun onServiceConnected() { inst = this }
    override fun onDestroy() { inst = null; super.onDestroy() }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun global(x: String): String {
        val g = when (x) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "quick" -> GLOBAL_ACTION_QUICK_SETTINGS
            "screenshot" -> GLOBAL_ACTION_TAKE_SCREENSHOT
            "lock" -> GLOBAL_ACTION_LOCK_SCREEN
            "power" -> GLOBAL_ACTION_POWER_DIALOG
            else -> return "bad global $x"
        }
        performGlobalAction(g)
        return ""
    }

    fun screen(): String {
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || sb.length > 3000) return
            val t = n.text ?: n.contentDescription
            if (t != null && t.isNotBlank()) sb.append(t).append(" | ")
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(rootInActiveWindow)
        return "SCREEN: $sb"
    }

    fun click(t: String): String {
        val r = rootInActiveWindow ?: return "window nahi mili"
        for (n in r.findAccessibilityNodeInfosByText(t)) {
            var p: AccessibilityNodeInfo? = n
            while (p != null && !p.isClickable) p = p.parent
            if (p != null) { p.performAction(AccessibilityNodeInfo.ACTION_CLICK); return "" }
        }
        return "'$t' screen pe nahi mila"
    }

    fun clickAny(l: List<String>): String {
        for (t in l) if (click(t).isEmpty()) return ""
        return "button nahi mila"
    }

    fun enter(): String {
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return "koi text box nahi"
        if (Build.VERSION.SDK_INT >= 30) f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        return ""
    }

    fun type(t: String): String {
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return "koi text box focus me nahi"
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
        return ""
    }

    fun scroll(dir: String): String {
        val m = resources.displayMetrics
        val w = m.widthPixels / 2f
        val h = m.heightPixels.toFloat()
        val p = Path()
        if (dir == "down") { p.moveTo(w, h * 0.7f); p.lineTo(w, h * 0.3f) } else { p.moveTo(w, h * 0.3f); p.lineTo(w, h * 0.7f) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 300)).build(), null, null)
        return ""
    }
}
