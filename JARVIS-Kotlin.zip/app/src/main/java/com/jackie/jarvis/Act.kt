package com.jackie.jarvis

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telephony.SmsManager
import android.view.KeyEvent

object Act {
    private fun go(c: Context, i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        (JarvisAccess.inst ?: c).startActivity(i)
    }

    fun run(c: Context, a: String, x: String, y: String): String {
        if (a in listOf("global", "click", "type", "scroll", "read_screen", "enter") && Prefs.get(c, "ctrl", "1") == "0")
            return "Phone control setting OFF hai"
        if (a in listOf("call", "sms", "whatsapp") && Prefs.get(c, "comm", "1") == "0")
            return "Call/message setting OFF hai"
        val r = try { exec(c, a, x, y) } catch (e: Exception) { "ERR $a: ${e.message}" }
        try {
            Thread.sleep(when (a) {
                "open_app", "web", "maps", "settings" -> 1800L
                "youtube" -> 1500L
                "global", "click", "scroll", "type", "enter" -> 700L
                else -> 0L
            })
        } catch (_: Exception) {}
        return r
    }

    /** Naam se number dhoondhta hai (fuzzy: "rahul bhai" -> "Rahul Bhai") */
    private fun findContact(c: Context, q: String): String {
        val toks = q.lowercase().split(Regex("\\s+")).filter { it.isNotBlank() }
        var best: String? = null
        var bestScore = 0
        var bestLen = 999
        c.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        )?.use { cur ->
            while (cur.moveToNext()) {
                val n = (cur.getString(0) ?: "").lowercase()
                val score = toks.count { n.contains(it) }
                if (score > 0 && (score > bestScore || (score == bestScore && n.length < bestLen))) {
                    bestScore = score; bestLen = n.length; best = cur.getString(1)
                }
            }
        }
        val b = best
        if (b == null || bestScore * 2 < toks.size) throw Exception("contact '$q' nahi mila (contacts permission ya naam check karo)")
        return b
    }

    private fun number(c: Context, x: String): String {
        val d = x.filter { it.isDigit() || it == '+' }
        if (d.count { it.isDigit() } >= 5) return d
        return findContact(c, x)
    }

    private fun waNumber(n: String): String {
        var d = n.filter { it.isDigit() }.trimStart('0')
        if (d.length == 10) d = "91$d"
        return d
    }

    private fun waSend(c: Context, who: String, text: String): String {
        val uri = Uri.parse("https://wa.me/" + waNumber(number(c, who)) + "?text=" + Uri.encode(text))
        var started = false
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b", null)) {
            try {
                go(c, Intent(Intent.ACTION_VIEW, uri).apply { if (pkg != null) setPackage(pkg) })
                started = true; break
            } catch (e: ActivityNotFoundException) {}
        }
        if (!started) return "WhatsApp nahi mila"
        if (Prefs.get(c, "autosend", "1") == "1") {
            Thread.sleep(3500)
            val acc = JarvisAccess.inst ?: return "Accessibility ON nahi hai, message Send nahi hua"
            if (acc.clickAny(listOf("Send", "भेजें", "भेजे")).isNotEmpty()) return "Message likha gaya par Send button nahi mila"
        }
        return ""
    }

    private fun openApp(c: Context, x: String): String {
        val pm = c.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val n = x.lowercase().trim()
        val m = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == n }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }
            ?: return "app nahi mila: $x"
        go(c, Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(m.activityInfo.packageName, m.activityInfo.name))
        return ""
    }

    private fun exec(c: Context, a: String, x: String, y: String): String {
        val am = c.getSystemService(AudioManager::class.java)
        when (a) {
            "open_app" -> return openApp(c, x)
            "call" -> {
                val act = if (c.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) Intent.ACTION_CALL else Intent.ACTION_DIAL
                go(c, Intent(act, Uri.parse("tel:" + number(c, x))))
            }
            "sms" -> {
                val n = number(c, x)
                if (Prefs.get(c, "autosend", "1") == "1" && c.checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                    @Suppress("DEPRECATION")
                    val sm = SmsManager.getDefault()
                    sm.sendMultipartTextMessage(n, null, sm.divideMessage(y), null, null)
                } else go(c, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$n")).putExtra("sms_body", y))
            }
            "whatsapp" -> return waSend(c, x, y)
            "web" -> go(c, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(x))))
            "youtube" -> go(c, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(x))))
            "yt_play" -> {
                try { go(c, Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", x)) }
                catch (e: Exception) { go(c, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(x)))) }
                val acc = JarvisAccess.inst
                if (acc != null && Prefs.get(c, "ctrl", "1") == "1") {
                    Thread.sleep(3500)
                    acc.clickAny(listOf("play video", "वीडियो चलाएं", "वीडियो चलाएँ"))
                }
            }
            "maps" -> go(c, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(x))))
            "alarm" -> {
                val p = x.split(":")
                go(c, Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, p[0].trim().toInt())
                    .putExtra(AlarmClock.EXTRA_MINUTES, p.getOrElse(1) { "0" }.trim().toInt())
                    .putExtra(AlarmClock.EXTRA_MESSAGE, y)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            }
            "timer" -> go(c, Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, x.trim().toInt())
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            "torch" -> {
                val cm = c.getSystemService(CameraManager::class.java)
                cm.setTorchMode(cm.cameraIdList[0], x == "on")
            }
            "volume" -> when (x) {
                "up" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                "down" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                "mute" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                else -> x.toIntOrNull()?.let {
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) * it / 100, AudioManager.FLAG_SHOW_UI)
                }
            }
            "media" -> {
                val k = when (x) {
                    "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
                    "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                    "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
                    else -> KeyEvent.KEYCODE_MEDIA_PLAY
                }
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, k))
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, k))
            }
            "settings" -> go(c, Intent(when (x) {
                "wifi" -> Settings.ACTION_WIFI_SETTINGS
                "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                "display" -> Settings.ACTION_DISPLAY_SETTINGS
                "sound" -> Settings.ACTION_SOUND_SETTINGS
                "apps" -> Settings.ACTION_APPLICATION_SETTINGS
                "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                else -> Settings.ACTION_SETTINGS
            }))
            "wait" -> Thread.sleep(((x.toDoubleOrNull() ?: 1.0).coerceIn(0.0, 5.0) * 1000).toLong())
            "global" -> return JarvisAccess.inst?.global(x) ?: "Accessibility ON nahi hai"
            "click" -> return JarvisAccess.inst?.click(x) ?: "Accessibility ON nahi hai"
            "type" -> return JarvisAccess.inst?.type(x) ?: "Accessibility ON nahi hai"
            "enter" -> return JarvisAccess.inst?.enter() ?: "Accessibility ON nahi hai"
            "scroll" -> return JarvisAccess.inst?.scroll(x) ?: "Accessibility ON nahi hai"
            "read_screen" -> {
                Thread.sleep(800)
                return JarvisAccess.inst?.screen() ?: "Accessibility ON nahi hai"
            }
            else -> return "unknown action $a"
        }
        return ""
    }
}
