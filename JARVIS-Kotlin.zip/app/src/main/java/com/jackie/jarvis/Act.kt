package com.jackie.jarvis

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.view.KeyEvent

object Act {
    private fun go(c: Context, i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        (JarvisAccess.inst ?: c).startActivity(i)
    }

    fun run(c: Context, a: String, x: String, y: String): String {
        if (a in listOf("global", "click", "type", "scroll", "read_screen") && Prefs.get(c, "ctrl", "1") == "0")
            return "Phone control setting OFF hai"
        if (a in listOf("call", "sms", "whatsapp") && Prefs.get(c, "comm", "1") == "0")
            return "Call/message setting OFF hai"
        val r = try { exec(c, a, x, y) } catch (e: Exception) { "ERR $a: ${e.message}" }
        try {
            Thread.sleep(when (a) {
                "open_app", "youtube", "web", "maps", "settings" -> 1800L
                "global", "click", "scroll", "type" -> 700L
                else -> 0L
            })
        } catch (_: Exception) {}
        return r
    }

    private fun number(c: Context, x: String): String {
        val d = x.filter { it.isDigit() || it == '+' }
        if (d.count { it.isDigit() } >= 5) return d
        c.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$x%"), null
        )?.use { if (it.moveToFirst()) return it.getString(0) }
        throw Exception("contact '$x' nahi mila")
    }

    private fun openApp(c: Context, x: String): String {
        val pm = c.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val n = x.lowercase().trim()
        val m = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == n }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }
            ?: return "app nahi mila: $x"
        go(c, Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(m.activityInfo.packageName, m.activityInfo.name))
        return ""
    }

    private fun exec(c: Context, a: String, x: String, y: String): String {
        val am = c.getSystemService(AudioManager::class.java)
        when (a) {
            "open_app" -> return openApp(c, x)
            "call" -> {
                val act = if (c.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) Intent.ACTION_CALL else Intent.ACTION_DIAL
                go(c, Intent(act, Uri.parse("tel:" + number(c, x))))
            }
            "sms" -> go(c, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + number(c, x))).putExtra("sms_body", y))
            "whatsapp" -> go(c, Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + number(c, x).filter { it.isDigit() } + "?text=" + Uri.encode(y))))
            "web" -> go(c, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(x))))
            "youtube" -> go(c, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(x))))
            "maps" -> go(c, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(x))))
            "alarm" -> {
                val p = x.split(":")
                go(c, Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, p[0].trim().toInt())
                    .putExtra(AlarmClock.EXTRA_MINUTES, p.getOrElse(1) { "0" }.trim().toInt())
                    .putExtra(AlarmClock.EXTRA_MESSAGE, y)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            }
            "timer" -> go(c, Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, x.trim().toInt())
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            "torch" -> {
                val cm = c.getSystemService(CameraManager::class.java)
                cm.setTorchMode(cm.cameraIdList[0], x == "on")
            }
            "volume" -> when (x) {
                "up" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                "down" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                "mute" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                else -> x.toIntOrNull()?.let {
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) * it / 100, AudioManager.FLAG_SHOW_UI)
                }
            }
            "media" -> {
                val k = when (x) {
                    "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
                    "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                    "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
                    else -> KeyEvent.KEYCODE_MEDIA_PLAY
                }
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, k))
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, k))
            }
            "settings" -> go(c, Intent(when (x) {
                "wifi" -> Settings.ACTION_WIFI_SETTINGS
                "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                "display" -> Settings.ACTION_DISPLAY_SETTINGS
                "sound" -> Settings.ACTION_SOUND_SETTINGS
                "apps" -> Settings.ACTION_APPLICATION_SETTINGS
                "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                else -> Settings.ACTION_SETTINGS
            }))
            "global" -> return JarvisAccess.inst?.global(x) ?: "Accessibility ON nahi hai"
            "click" -> return JarvisAccess.inst?.click(x) ?: "Accessibility ON nahi hai"
            "type" -> return JarvisAccess.inst?.type(x) ?: "Accessibility ON nahi hai"
            "scroll" -> return JarvisAccess.inst?.scroll(x) ?: "Accessibility ON nahi hai"
            "read_screen" -> {
                Thread.sleep(800)
                return JarvisAccess.inst?.screen() ?: "Accessibility ON nahi hai"
            }
            else -> return "unknown action $a"
        }
        return ""
    }
}
