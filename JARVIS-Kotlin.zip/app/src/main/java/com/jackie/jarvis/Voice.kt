package com.jackie.jarvis

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.PlaybackParams
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.atomic.AtomicInteger

/** JARVIS ki apni awaaz: OpenAI text-to-speech (phone ka system voice use nahi hota) */
object Voice {
    private const val STYLE = "Speak like a warm, relaxed young Indian friend chatting casually. Natural, expressive, a little playful, with human pauses and emotion. Never sound like a robot or a news announcer. Pronounce Hindi and Hinglish naturally."
    private val names = listOf("coral", "nova", "shimmer", "onyx", "echo", "ash")

    private lateinit var app: Context
    private var started = false
    private val texts = LinkedBlockingQueue<Pair<Int, String>>()
    private val audios = LinkedBlockingQueue<Pair<Int, ByteArray?>>(4)
    private val outstanding = AtomicInteger(0)
    @Volatile private var epoch = 0
    @Volatile private var track: AudioTrack? = null
    var onIdle: () -> Unit = {}
    var onError: (String) -> Unit = {}

    val busy: Boolean get() = outstanding.get() > 0

    fun init(c: Context) {
        if (started) return
        started = true
        app = c.applicationContext
        Thread { fetchLoop() }.apply { isDaemon = true }.start()
        Thread { playLoop() }.apply { isDaemon = true }.start()
    }

    fun say(t: String) {
        if (Prefs.get(app, "voice_on", "1") == "0" || t.isBlank()) return
        outstanding.incrementAndGet()
        texts.put(epoch to t)
    }

    fun stop() {
        epoch++
        texts.clear(); audios.clear()
        try { track?.pause(); track?.flush() } catch (_: Exception) {}
        outstanding.set(0)
    }

    private fun done() {
        if (outstanding.decrementAndGet() <= 0) { outstanding.set(0); onIdle() }
    }

    private fun fetchLoop() {
        while (true) {
            val (e, t) = texts.take()
            if (e != epoch) continue
            val pcm = try { synth(t) } catch (ex: Exception) { onError(Ai.friendly(ex.message)); null }
            if (e != epoch) continue
            audios.put(e to pcm)
        }
    }

    private fun playLoop() {
        while (true) {
            val (e, pcm) = audios.take()
            if (e != epoch) continue
            if (pcm != null) try { play(pcm, e) } catch (ex: Exception) { onError("Audio play error: ${ex.message}") }
            if (e == epoch) done()
        }
    }

    private fun voiceName(): String {
        val o = Prefs.get(app, "tts_voice").trim()
        if (o.isNotBlank()) return o
        return names[(Prefs.get(app, "voice", "0").toIntOrNull() ?: 0).coerceIn(0, 5)]
    }

    private fun synth(text: String): ByteArray {
        val key = Prefs.get(app, "tts_key").trim().ifBlank { Ai.key(app) }
        if (key.isEmpty()) throw Exception("Settings me API key daalo (awaaz ke liye bhi wahi key chalti hai)")
        val base = Prefs.get(app, "tts_base").trim().ifBlank { Ai.base(app) }.trimEnd('/')
        val model = Prefs.get(app, "tts_model").trim().ifBlank { "gpt-4o-mini-tts" }
        fun post(withStyle: Boolean): ByteArray {
            val b = JSONObject().put("model", model).put("input", text).put("voice", voiceName()).put("response_format", "pcm")
            if (withStyle) b.put("instructions", STYLE)
            val c = URL("$base/audio/speech").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true
            c.connectTimeout = 6000; c.readTimeout = 25000
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Authorization", "Bearer $key")
            c.outputStream.use { it.write(b.toString().toByteArray()) }
            if (c.responseCode !in 200..299) {
                val t = c.errorStream?.bufferedReader()?.readText() ?: ""
                throw Exception("HTTP ${c.responseCode} ${t.take(200)}")
            }
            return c.inputStream.use { it.readBytes() }
        }
        try { return post(true) } catch (e: Exception) {
            if ((e.message ?: "").contains("400")) return post(false)
            throw e
        }
    }

    private fun play(pcm: ByteArray, e: Int) {
        val min = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val tr = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(min, 24000))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track = tr
        try {
            val rate = Prefs.get(app, "rate", "1.0").toFloatOrNull() ?: 1f
            if (rate != 1f) tr.playbackParams = PlaybackParams().setSpeed(rate).setPitch(1f)
        } catch (_: Exception) {}
        tr.play()
        var off = 0
        while (off < pcm.size && e == epoch) {
            val n = tr.write(pcm, off, minOf(4096, pcm.size - off))
            if (n <= 0) break
            off += n
        }
        val frames = pcm.size / 2
        var guard = 0
        while (e == epoch && tr.playbackHeadPosition < frames && guard < 600) { Thread.sleep(25); guard++ }
        try { tr.stop() } catch (_: Exception) {}
        tr.release()
    }

    /** Settings ka awaaz test: asli error dikhata hai */
    fun test(): String = try {
        val pcm = synth("नमस्ते भाई, मैं जार्विस हूँ। ये मेरी अपनी आवाज़ है।")
        play(pcm, epoch)
        "✅ Awaaz chal gayi"
    } catch (e: Exception) {
        "❌ " + Ai.friendly(e.message)
    }
}
