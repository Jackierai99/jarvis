package com.jackie.jarvis

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.PlaybackParams
import android.speech.tts.TextToSpeech
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.atomic.AtomicInteger

private class Clip(val e: Int, val pcm: ByteArray?, val text: String)

/** JARVIS ki apni awaaz: Gemini TTS (FREE) ya OpenAI TTS. System voice sirf backup (limit bhar jaye tab). */
object Voice {
    private const val STYLE = "Speak like a warm, relaxed young Indian friend chatting casually. Natural, expressive, a little playful, with human pauses and emotion. Never sound like a robot or a news announcer. Pronounce Hindi and Hinglish naturally."
    private val openNames = listOf("coral", "nova", "shimmer", "onyx", "echo", "ash")
    private val gemNames = listOf("Kore", "Leda", "Aoede", "Charon", "Orus", "Fenrir")

    private lateinit var app: Context
    private var started = false
    private val texts = LinkedBlockingQueue<Pair<Int, String>>()
    private val audios = LinkedBlockingQueue<Clip>(4)
    private val outstanding = AtomicInteger(0)
    @Volatile private var epoch = 0
    @Volatile private var track: AudioTrack? = null
    private var sysTts: TextToSpeech? = null
    private var sysReady = false
    var onIdle: () -> Unit = {}
    var onError: (String) -> Unit = {}

    val busy: Boolean get() = outstanding.get() > 0

    fun init(c: Context) {
        if (started) return
        started = true
        app = c.applicationContext
        sysTts = TextToSpeech(app) { ok -> sysReady = ok == TextToSpeech.SUCCESS }
        Thread { fetchLoop() }.apply { isDaemon = true }.start()
        Thread { playLoop() }.apply { isDaemon = true }.start()
    }

    fun say(t: String) {
        if (Prefs.get(app, "voice_on", "1") == "0" || t.isBlank()) return
        outstanding.incrementAndGet()
        texts.put(epoch to t)
    }

    fun stop() {
        epoch++
        texts.clear(); audios.clear()
        try { track?.pause(); track?.flush() } catch (_: Exception) {}
        try { sysTts?.stop() } catch (_: Exception) {}
        outstanding.set(0)
    }

    private fun done() {
        if (outstanding.decrementAndGet() <= 0) { outstanding.set(0); onIdle() }
    }

    private fun fetchLoop() {
        while (true) {
            val (e, t) = texts.take()
            if (e != epoch) continue
            val pcm = try { synth(t) } catch (ex: Exception) { onError(Ai.friendly(ex.message)); null }
            if (e != epoch) continue
            audios.put(Clip(e, pcm, t))
        }
    }

    private fun playLoop() {
        while (true) {
            val c = audios.take()
            if (c.e != epoch) continue
            try {
                if (c.pcm != null) play(c.pcm, c.e) else fallback(c.text, c.e)
            } catch (ex: Exception) { onError("Audio play error: ${ex.message}") }
            if (c.e == epoch) done()
        }
    }

    /** Free limit bhar jaye ya net na ho to phone ki awaaz se bol do (setting se band kar sakte ho) */
    private fun fallback(text: String, e: Int) {
        if (Prefs.get(app, "fallback", "1") != "1" || !sysReady) return
        val t = sysTts ?: return
        t.language = if (text.any { it in '\u0900'..'\u097F' }) Locale("hi", "IN") else Locale("en", "IN")
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "fb" + System.nanoTime())
        Thread.sleep(400)
        var guard = 0
        while (e == epoch && t.isSpeaking && guard < 300) { Thread.sleep(100); guard++ }
    }

    private fun idx() = (Prefs.get(app, "voice", "0").toIntOrNull() ?: 0).coerceIn(0, 5)

    private fun voiceName(): String {
        return if (Ai.provider(app) == "gemini") gemNames[idx()] else openNames[idx()]
    }

    private fun synth(text: String): ByteArray = if (Ai.provider(app) == "gemini") synthGemini(text) else synthOpenAI(text)

    private fun geminiOnce(key: String, model: String, text: String): ByteArray {
        val prompt = "Say this like a close friend chatting casually, warm and natural, not like a robot: $text"
        val b = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voiceName())))))
        val c = URL("${Ai.GEM}/models/$model:generateContent").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true
        c.connectTimeout = 6000; c.readTimeout = 25000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(b.toString().toByteArray()) }
        if (c.responseCode !in 200..299) {
            val t = c.errorStream?.bufferedReader()?.readText() ?: ""
            throw Exception("HTTP ${c.responseCode} ${t.take(200)}")
        }
        val parts = JSONObject(c.inputStream.bufferedReader().readText())
            .optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
        if (parts != null) for (i in 0 until parts.length()) {
            val d = parts.getJSONObject(i).optJSONObject("inlineData")?.optString("data", "") ?: ""
            if (d.isNotEmpty()) return Base64.decode(d, Base64.DEFAULT)
        }
        throw Exception("awaaz khali aayi")
    }

    private fun synthGemini(text: String): ByteArray {
        val key = Ai.key(app)
        if (key.isEmpty()) throw Exception("Settings me API key daalo")
        var auto: String? = null
        if (Prefs.get(app, "tts_ok").isBlank()) {
            try { auto = Ai.pickTts(Ai.listModels(app)) } catch (_: Exception) {}
        }
        val models = listOfNotNull(
            Prefs.get(app, "tts_ok").ifBlank { null },
            auto
        ).plus(listOf("gemini-3.1-flash-tts-preview", "gemini-2.5-flash-preview-tts")).distinct()
        var err: Exception = Exception("tts error")
        for (m in models) {
            try {
                val r = geminiOnce(key, m, text)
                Prefs.set(app, "tts_ok", m)
                return r
            } catch (e: Exception) {
                err = e
                val s = e.message ?: ""
                if (s.contains("429")) {
                    Thread.sleep(1500)
                    try { return geminiOnce(key, m, text) } catch (e2: Exception) { err = e2 }
                    break
                }
                if (s.contains("401") || s.contains("403")) break
            }
        }
        throw err
    }

    private fun synthOpenAI(text: String): ByteArray {
        val key = Ai.key(app)
        if (key.isEmpty()) throw Exception("Settings me API key daalo")
        val base = Prefs.get(app, "tts_base").trim().ifBlank { Ai.base(app) }.trimEnd('/')
        val model = Prefs.get(app, "tts_model").trim().ifBlank { "gpt-4o-mini-tts" }
        fun post(withStyle: Boolean): ByteArray {
            val b = JSONObject().put("model", model).put("input", text).put("voice", voiceName()).put("response_format", "pcm")
            if (withStyle) b.put("instructions", STYLE)
            val c = URL("$base/audio/speech").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true
            c.connectTimeout = 6000; c.readTimeout = 25000
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Authorization", "Bearer $key")
            c.outputStream.use { it.write(b.toString().toByteArray()) }
            if (c.responseCode !in 200..299) {
                val t = c.errorStream?.bufferedReader()?.readText() ?: ""
                throw Exception("HTTP ${c.responseCode} ${t.take(200)}")
            }
            return c.inputStream.use { it.readBytes() }
        }
        try { return post(true) } catch (e: Exception) {
            if ((e.message ?: "").contains("400")) return post(false)
            throw e
        }
    }

    private fun play(pcm: ByteArray, e: Int) {
        val min = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val tr = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(min, 24000))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track = tr
        try {
            val rate = Prefs.get(app, "rate", "1.0").toFloatOrNull() ?: 1f
            if (rate != 1f) tr.playbackParams = PlaybackParams().setSpeed(rate).setPitch(1f)
        } catch (_: Exception) {}
        tr.play()
        var off = 0
        while (off < pcm.size && e == epoch) {
            val n = tr.write(pcm, off, minOf(4096, pcm.size - off))
            if (n <= 0) break
            off += n
        }
        val frames = pcm.size / 2
        var guard = 0
        while (e == epoch && tr.playbackHeadPosition < frames && guard < 800) { Thread.sleep(25); guard++ }
        try { tr.stop() } catch (_: Exception) {}
        tr.release()
    }

    /** Settings ka awaaz test: asli error dikhata hai */
    fun test(): String = try {
        val pcm = synth("नमस्ते भाई, मैं जार्विस हूँ। ये मेरी अपनी आवाज़ है।")
        play(pcm, epoch)
        "✅ Awaaz chal gayi"
    } catch (e: Exception) {
        "❌ " + Ai.friendly(e.message)
    }
}
