package com.jackie.jarvis

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    fun get(c: Context, k: String, d: String = ""): String = sp(c).getString(k, d) ?: d
    fun set(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
}

object Ai {
    val providers = listOf("gemini", "claude", "openai")
    private val defModel = mapOf("gemini" to "gemini-2.5-flash", "claude" to "claude-sonnet-5-5", "openai" to "gpt-4o-mini")

    fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        return c.inputStream.bufferedReader().readText()
    }

    private fun post(url: String, headers: Map<String, String>, body: JSONObject): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 60000; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val ok = c.responseCode in 200..299
        val t = (if (ok) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        if (!ok) throw Exception("HTTP ${c.responseCode} ${t.take(160)}")
        return t
    }

    private fun ask(ctx: Context, p: String, system: String, hist: List<Pair<String, String>>): String {
        val key = Prefs.get(ctx, "key_$p").trim()
        if (key.isEmpty()) throw Exception("key missing")
        val model = Prefs.get(ctx, "model_$p").trim().ifBlank { defModel[p]!! }
        return when (p) {
            "gemini" -> {
                val contents = JSONArray()
                hist.forEach { (r, t) ->
                    contents.put(JSONObject().put("role", if (r == "user") "user" else "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", t))))
                }
                val b = JSONObject().put("contents", contents)
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                    .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
                val r = JSONObject(post("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent", mapOf("x-goog-api-key" to key), b))
                r.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            }
            "claude" -> {
                val m = JSONArray()
                hist.forEach { (r, t) -> m.put(JSONObject().put("role", r).put("content", t)) }
                val b = JSONObject().put("model", model).put("max_tokens", 1024).put("system", system).put("messages", m)
                val r = JSONObject(post("https://api.anthropic.com/v1/messages", mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), b))
                r.getJSONArray("content").getJSONObject(0).getString("text")
            }
            else -> {
                val m = JSONArray().put(JSONObject().put("role", "system").put("content", system))
                hist.forEach { (r, t) -> m.put(JSONObject().put("role", r).put("content", t)) }
                val b = JSONObject().put("model", model).put("messages", m)
                val r = JSONObject(post("https://api.openai.com/v1/chat/completions", mapOf("Authorization" to "Bearer $key"), b))
                r.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            }
        }
    }

    /** auto = jis jis ki key hai unhe ek ek karke try karta hai (fallback). */
    fun chat(ctx: Context, system: String, hist: List<Pair<String, String>>): String {
        val pref = Prefs.get(ctx, "provider", "auto")
        val order = if (pref == "auto") providers.filter { Prefs.get(ctx, "key_$it").isNotBlank() } else listOf(pref)
        if (order.isEmpty()) throw Exception("Settings me API key daalo")
        val errs = ArrayList<String>()
        for (p in order) {
            try { return ask(ctx, p, system, hist) } catch (e: Exception) { errs.add("$p: ${e.message}") }
        }
        throw Exception(errs.joinToString(" | "))
    }
}
