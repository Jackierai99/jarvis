package com.jackie.jarvis

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    fun get(c: Context, k: String, d: String = ""): String = sp(c).getString(k, d) ?: d
    fun set(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
}

object Ai {
    fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        return c.inputStream.bufferedReader().readText()
    }

    private fun post(url: String, key: String, body: JSONObject): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 10000; c.readTimeout = 30000; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val ok = c.responseCode in 200..299
        val t = (if (ok) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        if (!ok) throw Exception("HTTP ${c.responseCode} ${t.take(180)}")
        return t
    }

    private fun ask(key: String, model: String, system: String, hist: List<Pair<String, String>>): String {
        val contents = JSONArray()
        hist.forEach { (r, t) ->
            contents.put(JSONObject().put("role", if (r == "user") "user" else "model")
                .put("parts", JSONArray().put(JSONObject().put("text", t))))
        }
        val gen = JSONObject().put("responseMimeType", "application/json").put("maxOutputTokens", 400).put("temperature", 0.6)
        if (model.contains("2.5")) gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
        val b = JSONObject().put("contents", contents)
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("generationConfig", gen)
        val r = JSONObject(post("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent", key, b))
        return r.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    }

    /** Sirf Gemini. Model fail ho toh agla model try karta hai. */
    fun chat(ctx: Context, system: String, hist: List<Pair<String, String>>): String {
        val key = Prefs.get(ctx, "key_gemini").trim()
        if (key.isEmpty()) throw Exception("Settings me Gemini API key daalo")
        val custom = Prefs.get(ctx, "model_gemini").trim()
        val models = listOfNotNull(custom.ifBlank { null }, "gemini-2.5-flash", "gemini-2.0-flash", "gemini-flash-latest").distinct()
        var err = ""
        for (m in models) {
            try { return ask(key, m, system, hist) } catch (e: Exception) {
                err = e.message ?: "error"
                if (err.contains("401") || err.contains("403") || err.contains("API key")) break
            }
        }
        throw Exception(err)
    }
}
