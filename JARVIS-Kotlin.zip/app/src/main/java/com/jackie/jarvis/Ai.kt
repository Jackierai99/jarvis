package com.jackie.jarvis

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    fun get(c: Context, k: String, d: String = ""): String = sp(c).getString(k, d) ?: d
    fun set(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
}

/** Provider: gemini (FREE, default) / openai (paid) / custom (Groq, OpenRouter...) -- sab OpenAI-style chat API */
object Ai {
    const val GEM = "https://generativelanguage.googleapis.com/v1beta"

    fun provider(c: Context): String = "gemini"
    fun key(c: Context): String = Prefs.get(c, "key_ai").trim()
    fun base(c: Context): String = when (provider(c)) {
        "gemini" -> "$GEM/openai"
        "openai" -> "https://api.openai.com/v1"
        else -> Prefs.get(c, "base").trim().ifBlank { "https://api.openai.com/v1" }.trimEnd('/')
    }

    private val openFast = listOf("gpt-5.4-mini", "gpt-5-mini", "gpt-4.1-mini", "gpt-4o-mini")
    private val openSmart = listOf("gpt-5.5-chat-latest", "gpt-5.4", "gpt-5.2-chat-latest", "gpt-4.1", "gpt-4o")
    private val gemFast = listOf("gemini-3.5-flash-lite", "gemini-3.1-flash-lite", "gemini-3.5-flash")
    private val gemSmart = listOf("gemini-3.5-flash", "gemini-3.1-flash-lite")
    private val bad = listOf("embed", "tts", "whisper", "image", "audio", "realtime", "moderation", "transcribe", "dall", "search", "codex", "pro", "instruct", "live", "robotics", "computer", "veo", "imagen", "native")

    fun friendly(m: String?): String {
        val e = m ?: "error"
        return when {
            e.contains("401") || e.contains("403") || e.contains("API key not valid") || e.contains("Incorrect API key") -> "API key galat ya band hai (naya key banao)"
            e.contains("429") || e.contains("quota", true) || e.contains("billing", true) -> "Limit bhar gayi (free me 1 min ruk ke try karo, paid me credit check karo)"
            e.contains("404") -> "Ye model nahi mila (Key test karo ya model naam badlo)"
            e.contains("timeout", true) || e.contains("Unable to resolve") || e.contains("failed to connect", true) -> "Internet ya network problem (timeout)"
            else -> e.take(150)
        }
    }

    fun ver(n: String): Double = Regex("gemini-(\\d+(?:\\.\\d+)?)").find(n)?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0

    private fun pickGemini(names: List<String>, fast: Boolean): String? {
        val ok = names.filter { it.startsWith("gemini-") && it.contains("flash") && bad.none { b -> it.contains(b) } }
        fun best(l: List<String>) = l.maxWithOrNull(compareBy<String>({ ver(it) }, { if (it.contains("preview") || it.contains("exp")) 0 else 1 }))
        val lite = ok.filter { it.contains("lite") }
        val full = ok.filter { !it.contains("lite") }
        return if (fast) best(lite) ?: best(full) else best(full) ?: best(lite)
    }

    fun pickTts(names: List<String>): String? {
        val t = names.filter { it.startsWith("gemini-") && it.contains("tts") }
        return t.maxWithOrNull(compareBy<String>({ ver(it) }, { if (it.contains("lite")) 1 else 0 }, { if (it.contains("preview")) 0 else 1 }))
    }

    private fun httpJson(url: String, key: String, bearer: Boolean): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 6000; c.readTimeout = 15000
        if (bearer) c.setRequestProperty("Authorization", "Bearer $key") else c.setRequestProperty("x-goog-api-key", key)
        val ok = c.responseCode in 200..299
        val t = (if (ok) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        if (!ok) throw Exception("HTTP ${c.responseCode} ${t.take(200)}")
        return t
    }

    /** Models ki list (generate karne wale) */
    fun listModels(ctx: Context): List<String> {
        val names = ArrayList<String>()
        if (provider(ctx) == "gemini") {
            val arr = JSONObject(httpJson("$GEM/models?pageSize=200", key(ctx), false)).optJSONArray("models") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val m = arr.getJSONObject(i)
                if (m.optJSONArray("supportedGenerationMethods")?.toString()?.contains("generateContent") == true)
                    names.add(m.getString("name").removePrefix("models/"))
            }
        } else {
            val arr = JSONObject(httpJson(base(ctx) + "/models", key(ctx), true)).optJSONArray("data") ?: JSONArray()
            for (i in 0 until arr.length()) names.add(arr.getJSONObject(i).optString("id").removePrefix("models/"))
        }
        return names
    }

    private fun mode(ctx: Context) = Prefs.get(ctx, "mode", "fast")
    private fun modeKey(ctx: Context) = "model_ok_${provider(ctx)}_${mode(ctx)}"

    private fun detect(ctx: Context, names: List<String>): String? {
        val fast = mode(ctx) == "fast"
        return if (provider(ctx) == "gemini") pickGemini(names, fast)
        else (if (fast) openFast else openSmart).firstOrNull { it in names }
            ?: names.firstOrNull { n -> n.startsWith("gpt") && bad.none { n.contains(it) } }
    }

    private fun body(ctx: Context, model: String, system: String, hist: List<Pair<String, String>>, full: Boolean): JSONObject {
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system))
        hist.forEach { (r, t) -> msgs.put(JSONObject().put("role", r).put("content", t)) }
        val b = JSONObject().put("model", model).put("messages", msgs).put("stream", true)
        if (full) {
            b.put("response_format", JSONObject().put("type", "json_object"))
            b.put("max_completion_tokens", 700)
            if (model.startsWith("gemini-3")) b.put("reasoning_effort", "minimal")
            else if (model.startsWith("gpt-5") || model.startsWith("o")) b.put("reasoning_effort", "low")
        }
        return b
    }

    private fun stream(ctx: Context, model: String, system: String, hist: List<Pair<String, String>>, full: Boolean, onText: (String) -> Unit): String {
        val c = URL(base(ctx) + "/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true
        c.connectTimeout = 6000; c.readTimeout = 20000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Authorization", "Bearer " + key(ctx))
        c.outputStream.use { it.write(body(ctx, model, system, hist, full).toString().toByteArray()) }
        if (c.responseCode !in 200..299) {
            val t = c.errorStream?.bufferedReader()?.readText() ?: ""
            throw Exception("HTTP ${c.responseCode} ${t.take(220)}")
        }
        val sb = StringBuilder()
        c.inputStream.bufferedReader().use { r ->
            while (true) {
                val line = r.readLine() ?: break
                if (!line.startsWith("data:")) continue
                val js = line.substring(5).trim()
                if (js.isEmpty()) continue
                if (js == "[DONE]") break
                try {
                    val d = JSONObject(js).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("delta")
                    val t = d?.optString("content", "") ?: ""
                    if (t.isNotEmpty()) { sb.append(t); onText(sb.toString()) }
                } catch (_: Exception) {}
            }
        }
        if (sb.isBlank()) throw Exception("empty reply")
        return sb.toString()
    }

    private fun ask(ctx: Context, model: String, system: String, hist: List<Pair<String, String>>, onText: (String) -> Unit): String {
        try { return stream(ctx, model, system, hist, true, onText) } catch (e: Exception) {
            if ((e.message ?: "").contains("400")) return stream(ctx, model, system, hist, false, onText)
            throw e
        }
    }

    private fun order(ctx: Context): List<String> {
        var cached = Prefs.get(ctx, modeKey(ctx))
        if (cached.isBlank()) {
            try { detect(ctx, listModels(ctx))?.let { cached = it; Prefs.set(ctx, modeKey(ctx), it) } } catch (_: Exception) {}
        }
        val fast = mode(ctx) == "fast"
        val defaults = if (provider(ctx) == "gemini") (if (fast) gemFast else gemSmart) else (if (fast) openFast else openSmart)
        return listOfNotNull(cached.ifBlank { null }).plus(defaults).distinct()
    }

    fun chat(ctx: Context, system: String, hist: List<Pair<String, String>>, onText: (String) -> Unit): String {
        if (key(ctx).isEmpty()) throw Exception("Settings me API key daalo")
        val t0 = System.currentTimeMillis()
        var err = ""
        for (m in order(ctx)) {
            if (System.currentTimeMillis() - t0 > 30000) break
            try {
                val r = ask(ctx, m, system, hist, onText)
                Prefs.set(ctx, modeKey(ctx), m)
                return r
            } catch (e: Exception) {
                err = e.message ?: "error"
                if (err.contains("401") || err.contains("403")) break
            }
        }
        throw Exception(friendly(err))
    }

    /** Settings ka "Key test" button */
    fun test(ctx: Context): String {
        if (key(ctx).isEmpty()) return "❌ Pehle API key daalo"
        val sb = StringBuilder()
        val names = try { listModels(ctx) } catch (e: Exception) { return "❌ Key check fail: ${friendly(e.message)}" }
        sb.append("✅ Key sahi hai (${names.size} models mile)\n")
        val chosen = detect(ctx, names)
            ?: return sb.append("❌ Koi chat model nahi mila (Settings me model naam daalo)").toString()
        Prefs.set(ctx, modeKey(ctx), chosen)
        val ttsLine = if (provider(ctx) == "gemini") {
            val t = pickTts(names)
            if (t != null) { Prefs.set(ctx, "tts_ok", t); "\nAwaaz model: $t" } else "\nAwaaz model: default try hoga"
        } else ""
        return try {
            val t0 = System.currentTimeMillis()
            ask(ctx, chosen, "Reply only JSON.", listOf("user" to "Return {\"say\":\"OK\"}")) {}
            val s = (System.currentTimeMillis() - t0) / 1000.0
            sb.append("✅ Reply mila (${"%.1f".format(s)}s)\nModel: $chosen$ttsLine").toString()
        } catch (e: Exception) {
            sb.append("❌ Reply fail ($chosen): ${friendly(e.message)}").toString()
        }
    }
}
