package com.jackie.jarvis

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    fun get(c: Context, k: String, d: String = ""): String = sp(c).getString(k, d) ?: d
    fun set(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
}

object Ai {
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/"
    // Gemini 2.5 / 2.0 band ho chuke hain (Oct 2026), isliye naye models
    private val defaults = listOf("gemini-3.1-flash-lite", "gemini-3.5-flash", "gemini-flash-latest")

    fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        return c.inputStream.bufferedReader().readText()
    }

    private fun call(url: String, key: String, body: JSONObject?): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 6000; c.readTimeout = 18000
        c.setRequestProperty("x-goog-api-key", key)
        if (body != null) {
            c.requestMethod = "POST"; c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
        }
        val ok = c.responseCode in 200..299
        val t = (if (ok) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        if (!ok) throw Exception("HTTP ${c.responseCode} ${t.take(200)}")
        return t
    }

    private fun ask2(key: String, model: String, system: String, hist: List<Pair<String, String>>, think: Boolean): String {
        val contents = JSONArray()
        hist.forEach { (r, t) ->
            contents.put(JSONObject().put("role", if (r == "user") "user" else "model")
                .put("parts", JSONArray().put(JSONObject().put("text", t))))
        }
        val gen = JSONObject().put("responseMimeType", "application/json").put("maxOutputTokens", 500).put("temperature", 0.6)
        if (think) gen.put("thinkingConfig", JSONObject().put("thinkingLevel", "low"))
        val b = JSONObject().put("contents", contents)
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("generationConfig", gen)
        val r = JSONObject(call(BASE + "models/$model:generateContent", key, b))
        return r.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    }

    private fun ask(key: String, model: String, system: String, hist: List<Pair<String, String>>): String {
        val think = model.contains("3.5") || model.contains("3-flash")
        try { return ask2(key, model, system, hist, think) } catch (e: Exception) {
            if (think && (e.message ?: "").contains("400")) return ask2(key, model, system, hist, false)
            throw e
        }
    }

    fun friendly(m: String?): String {
        val e = m ?: "error"
        return when {
            e.contains("API key not valid") || e.contains("401") || e.contains("403") -> "Key galat ya band hai (naya key banao: aistudio.google.com/apikey)"
            e.contains("429") -> "Quota khatam / bahut requests. Thodi der baad try karo"
            e.contains("404") -> "Ye model ab available nahi"
            e.contains("timeout", true) || e.contains("Unable to resolve") || e.contains("failed to connect", true) -> "Internet ya network problem (timeout)"
            else -> e.take(140)
        }
    }

    fun chat(ctx: Context, system: String, hist: List<Pair<String, String>>): String {
        val key = Prefs.get(ctx, "key_gemini").trim()
        if (key.isEmpty()) throw Exception("Settings me Gemini API key daalo")
        val models = listOfNotNull(
            Prefs.get(ctx, "model_gemini").trim().ifBlank { null },
            Prefs.get(ctx, "model_ok").ifBlank { null }
        ).plus(defaults).distinct()
        val t0 = System.currentTimeMillis()
        var err = ""
        for (m in models) {
            if (System.currentTimeMillis() - t0 > 30000) break
            try {
                val r = ask(key, m, system, hist)
                Prefs.set(ctx, "model_ok", m)
                return r
            } catch (e: Exception) {
                err = e.message ?: "error"
                if (err.contains("401") || err.contains("403") || err.contains("API key")) break
            }
        }
        throw Exception(friendly(err))
    }

    /** Settings ka "Key test" button: key check + chalta hua model dhoondhna + reply test */
    fun test(ctx: Context): String {
        val key = Prefs.get(ctx, "key_gemini").trim()
        if (key.isEmpty()) return "❌ Pehle Gemini key daalo"
        val sb = StringBuilder()
        val chosen: String
        try {
            val arr = JSONObject(call(BASE + "models?pageSize=200", key, null)).optJSONArray("models") ?: JSONArray()
            val names = ArrayList<String>()
            for (i in 0 until arr.length()) {
                val m = arr.getJSONObject(i)
                if (m.optJSONArray("supportedGenerationMethods")?.toString()?.contains("generateContent") == true)
                    names.add(m.getString("name").removePrefix("models/"))
            }
            sb.append("✅ Key sahi hai (${names.size} models mile)\n")
            val bad = listOf("image", "tts", "live", "embed", "audio", "robotics", "computer", "veo", "imagen")
            val pick = (listOf("gemini-3.1-flash-lite", "gemini-3.5-flash", "gemini-3-flash-preview", "gemini-flash-latest").firstOrNull { it in names }
                ?: names.firstOrNull { it.contains("flash") && bad.none { b -> it.contains(b) } })
                ?: return sb.append("❌ Koi chat model nahi mila").toString()
            chosen = pick
            Prefs.set(ctx, "model_ok", chosen)
        } catch (e: Exception) {
            return "❌ Key check fail: ${friendly(e.message)}"
        }
        return try {
            val t0 = System.currentTimeMillis()
            ask(key, chosen, "Reply only JSON.", listOf("user" to "Return {\"say\":\"OK\"}"))
            val s = (System.currentTimeMillis() - t0) / 1000.0
            sb.append("✅ Reply mila (${"%.1f".format(s)}s)\nModel: $chosen").toString()
        } catch (e: Exception) {
            sb.append("❌ Reply fail ($chosen): ${friendly(e.message)}").toString()
        }
    }
}
