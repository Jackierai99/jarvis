package com.jackie.jarvis

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    fun get(c: Context, k: String, d: String = ""): String = sp(c).getString(k, d) ?: d
    fun set(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
}

object Ai {
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/"

    fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        return c.inputStream.bufferedReader().readText()
    }

    private fun call(url: String, key: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 6000; c.readTimeout = 15000
        c.setRequestProperty("x-goog-api-key", key)
        val ok = c.responseCode in 200..299
        val t = (if (ok) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        if (!ok) throw Exception("HTTP ${c.responseCode} ${t.take(200)}")
        return t
    }

    private fun body(system: String, hist: List<Pair<String, String>>, think: Boolean): JSONObject {
        val contents = JSONArray()
        hist.forEach { (r, t) ->
            contents.put(JSONObject().put("role", if (r == "user") "user" else "model")
                .put("parts", JSONArray().put(JSONObject().put("text", t))))
        }
        val gen = JSONObject().put("responseMimeType", "application/json").put("maxOutputTokens", 700).put("temperature", 0.6)
        if (think) gen.put("thinkingConfig", JSONObject().put("thinkingLevel", "minimal"))
        return JSONObject().put("contents", contents)
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("generationConfig", gen)
    }

    /** Streaming: jaise jaise text aata hai onText(ab tak ka poora text) bulata hai */
    private fun stream(key: String, model: String, system: String, hist: List<Pair<String, String>>, think: Boolean, onText: (String) -> Unit): String {
        val c = URL(BASE + "models/$model:streamGenerateContent?alt=sse").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true
        c.connectTimeout = 6000; c.readTimeout = 15000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body(system, hist, think).toString().toByteArray()) }
        if (c.responseCode !in 200..299) {
            val t = c.errorStream?.bufferedReader()?.readText() ?: ""
            throw Exception("HTTP ${c.responseCode} ${t.take(200)}")
        }
        val sb = StringBuilder()
        c.inputStream.bufferedReader().use { r ->
            while (true) {
                val line = r.readLine() ?: break
                if (!line.startsWith("data:")) continue
                val js = line.substring(5).trim()
                if (js.isEmpty()) continue
                try {
                    val parts = JSONObject(js).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                    if (parts != null) for (i in 0 until parts.length()) {
                        val p = parts.getJSONObject(i)
                        if (!p.optBoolean("thought", false)) sb.append(p.optString("text"))
                    }
                    onText(sb.toString())
                } catch (_: Exception) {}
            }
        }
        if (sb.isBlank()) throw Exception("empty reply")
        return sb.toString()
    }

    private fun ask(key: String, model: String, system: String, hist: List<Pair<String, String>>, onText: (String) -> Unit): String {
        val think = model.startsWith("gemini-3")
        try { return stream(key, model, system, hist, think, onText) } catch (e: Exception) {
            if (think && (e.message ?: "").contains("400")) return stream(key, model, system, hist, false, onText)
            throw e
        }
    }

    fun friendly(m: String?): String {
        val e = m ?: "error"
        return when {
            e.contains("API key not valid") || e.contains("401") || e.contains("403") -> "Key galat ya band hai (naya key banao: aistudio.google.com/apikey)"
            e.contains("429") -> "Quota khatam / bahut requests. Thodi der baad try karo"
            e.contains("404") -> "Ye model ab available nahi"
            e.contains("timeout", true) || e.contains("Unable to resolve") || e.contains("failed to connect", true) -> "Internet ya network problem (timeout)"
            else -> e.take(140)
        }
    }

    private fun order(ctx: Context): List<String> {
        val fast = Prefs.get(ctx, "mode", "smart") == "fast"
        val base = if (fast) listOf("gemini-3.5-flash-lite", "gemini-3.1-flash-lite", "gemini-3.5-flash")
        else listOf("gemini-3.5-flash", "gemini-3.1-flash-lite", "gemini-flash-latest")
        return listOfNotNull(
            Prefs.get(ctx, "model_gemini").trim().ifBlank { null },
            Prefs.get(ctx, "model_ok_" + (if (fast) "fast" else "smart")).ifBlank { null }
        ).plus(base).distinct()
    }

    fun chat(ctx: Context, system: String, hist: List<Pair<String, String>>, onText: (String) -> Unit): String {
        val key = Prefs.get(ctx, "key_gemini").trim()
        if (key.isEmpty()) throw Exception("Settings me Gemini API key daalo")
        val t0 = System.currentTimeMillis()
        var err = ""
        for (m in order(ctx)) {
            if (System.currentTimeMillis() - t0 > 30000) break
            try {
                val r = ask(key, m, system, hist, onText)
                Prefs.set(ctx, "model_ok_" + (if (Prefs.get(ctx, "mode", "smart") == "fast") "fast" else "smart"), m)
                return r
            } catch (e: Exception) {
                err = e.message ?: "error"
                if (err.contains("401") || err.contains("403") || err.contains("API key")) break
            }
        }
        throw Exception(friendly(err))
    }

    /** Settings ka "Key test" button */
    fun test(ctx: Context): String {
        val key = Prefs.get(ctx, "key_gemini").trim()
        if (key.isEmpty()) return "❌ Pehle Gemini key daalo"
        val sb = StringBuilder()
        val names = ArrayList<String>()
        try {
            val arr = JSONObject(call(BASE + "models?pageSize=200", key)).optJSONArray("models") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val m = arr.getJSONObject(i)
                if (m.optJSONArray("supportedGenerationMethods")?.toString()?.contains("generateContent") == true)
                    names.add(m.getString("name").removePrefix("models/"))
            }
            sb.append("✅ Key sahi hai (${names.size} models mile)\n")
        } catch (e: Exception) {
            return "❌ Key check fail: ${friendly(e.message)}"
        }
        val fast = Prefs.get(ctx, "mode", "smart") == "fast"
        val pri = if (fast) listOf("gemini-3.5-flash-lite", "gemini-3.1-flash-lite", "gemini-3.5-flash")
        else listOf("gemini-3.5-flash", "gemini-3.1-flash-lite", "gemini-3-flash-preview", "gemini-flash-latest")
        val bad = listOf("image", "tts", "live", "embed", "audio", "robotics", "computer", "veo", "imagen")
        val chosen = pri.firstOrNull { it in names }
            ?: names.firstOrNull { it.contains("flash") && bad.none { b -> it.contains(b) } }
            ?: return sb.append("❌ Koi chat model nahi mila").toString()
        Prefs.set(ctx, "model_ok_" + (if (fast) "fast" else "smart"), chosen)
        return try {
            val t0 = System.currentTimeMillis()
            ask(key, chosen, "Reply only JSON.", listOf("user" to "Return {\"say\":\"OK\"}")) {}
            val s = (System.currentTimeMillis() - t0) / 1000.0
            sb.append("✅ Reply mila (${"%.1f".format(s)}s)\nModel: $chosen").toString()
        } catch (e: Exception) {
            sb.append("❌ Reply fail ($chosen): ${friendly(e.message)}").toString()
        }
    }
}
