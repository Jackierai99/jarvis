JARVIS (Kotlin + Compose) - GitHub se APK
1. Is zip ke andar ki saari files apne GitHub repo me upload karo (.github folder bhi).
2. Actions tab -> Build APK -> run ho jayega -> artifact "JARVIS-apk" download karo.
3. App kholo -> gear icon -> API key daalo -> Accessibility ON karo -> mic tap karo.
